/*
 * Copyright (C) 2011 xjuraj
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.multithreaddownloader.document;

import junit.framework.TestCase;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.Charset;

/**
 *
 * @author xjuraj
 */
public class RemoteFileEncodingTest extends TestCase {
    
    public RemoteFileEncodingTest(String testName) {
        super(testName);
    }
    
    @Override
    protected void setUp() throws Exception {
        super.setUp();
    }
    
    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    /**
     * Test of makeEncoding method, of class RemoteFileEncoding.
     */
    public void testMakeEncoding() {
        System.out.println("makeEncoding");
        String encoding = "utf-8";
        Charset expResult = Charset.forName("utf-8");
        RemoteFileEncoding fileEncoding = new RemoteFileEncoding();
        Charset result = fileEncoding.makeEncoding(encoding);
        assertEquals(expResult, result);
    }

    /**
     * Test of guessEncoding method, of class RemoteFileEncoding.
     */
    public void testGuessEncoding() {
//        System.out.println("guessEncoding");
//        File file = null;
//        String serverMimeType = "";
//        String remoteContentEncoding = "";
//        Charset expResult = null;
//        Charset result = RemoteFileEncoding.guessEncoding(file, serverMimeType, remoteContentEncoding);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of tryParseMimeType method, of class RemoteFileEncoding.
     */
    public void testTryParseMimeType() {
//        System.out.println("tryParseMimeType");
//        String mimeType = "";
//        Charset expResult = null;
//        Charset result = RemoteFileEncoding.tryParseMimeType(mimeType);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of fileEncoding method, of class RemoteFileEncoding.
     */
    public void testFileEncoding() throws Exception {
        System.out.println("fileEncoding");
        File f = new File("test-files/encoding/enc_utf8");
        System.out.println(f.getAbsoluteFile());
        RemoteFileEncoding fileEncoding = new RemoteFileEncoding();
        
        InputStream is = new BufferedInputStream(new FileInputStream(f));
        int length = (int)f.length();
        Charset expResult = Charset.forName("utf-8");
        Charset result = fileEncoding.fileEncoding(f);
//        Charset result = RemoteFileEncoding.fileEncoding(is, length);
//        Charset result = RemoteFileEncoding.fileEncoding(f.toURI().toURL());
        assertEquals(expResult, result);
        
        f = new File("test-files/encoding/enc_windows-1250.html");
        is = new BufferedInputStream(new FileInputStream(f));
        length = (int)f.length();
        expResult = Charset.forName("windows-1250");
        result = fileEncoding.fileEncoding(f);
//        result = RemoteFileEncoding.fileEncoding(is, length);
        assertEquals(expResult, result);
    }

    /**
     * Test of selectCharset method, of class RemoteFileEncoding.
     */
    public void testSelectCharset() throws Exception {
//        System.out.println("selectCharset");
//        Charset[] charsets = null;
//        Charset expResult = null;
//        Charset result = RemoteFileEncoding.selectCharset(charsets);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }
}
