/*
 * Copyright (C) 2011 JiangHongTiao
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.multithreaddownloader.request.converter;

import org.apache.log4j.Logger;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.exceptions.OutOfRangeException;

import java.util.Arrays;

/**
 * Date of create: May 20, 2011
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 * @version 2011.0520
 */
public class NumberEnumConverter implements Converter {

    private String convType;
    private String[] values;
    Logger log = Logger.getLogger(LengthRangeConverter.class.getName());

    public NumberEnumConverter(String convType, String[] values) {
        log.debug("NumberEnumConverter created with type=" + convType
                + " and values: " + Arrays.toString(values));
        if (convType == null) {
            throw new NullPointerException("Convert Type is null!");
        }
        if ((values == null) || (values.length == 0)) {
            throw new NullPointerException("Values array is null or empty!");
        }
        this.convType = convType.toLowerCase();
        this.values = values;
    }

    @Override
    public String convert(String value) throws Exception {
        log.debug("NumberEnumConverter created with type=" + convType
                + " and value: " + Arrays.toString(values));
        if (convType.equals("short")) {
            short v = Short.parseShort(value);
            for (String val : values) {
                if (Short.parseShort(val) == v) {
                    return value;
                }
            }
        }
        if (convType.equals("int") || convType.equals("integer")) {
            int v = Integer.parseInt(value);
            for (String val : values) {
                if (Integer.parseInt(val) == v) {
                    return value;
                }
            }
        }
        if (convType.equals("double")) {
            double v = Double.parseDouble(value);
            for (String val : values) {
                if (Double.parseDouble(val) == v) {
                    return value;
                }
            }
        }
        if (convType.equals("float")) {
            float v = Float.parseFloat(value);
            for (String val : values) {
                if (Float.parseFloat(val) == v) {
                    return value;
                }
            }
        }
        throw new OutOfRangeException("Value is out of the range! value was: '"
                + value + "' but expected are: " + Arrays.toString(values));
    }
}
