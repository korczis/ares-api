/*
 * Copyright (C) 2011 JiangHongTiao
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.multithreaddownloader.request.params;

import org.apache.log4j.Logger;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.converter.Converter;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * Date of create: May 19, 2011
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 * @version 2011.0519
 */
public class ParamImpl implements Param{
    
    private String name;
    private String value;
    private Converter converter;
    private Logger log = Logger.getLogger(this.getClass().getName());

    public ParamImpl(String name, Converter converter) {
        log.debug("Param created with name="+name);
        this.name = name;
        this.converter = converter;
    }

    public ParamImpl(String name, String value, Converter converter) {
        log.debug("Param created with name="+name+" and value="+value);
        this.name = name;
        this.value = value;
        this.converter = converter;
    }
    
    protected void setConverter(Converter converter){
        log.debug("Set converter.");
        this.converter = converter;
    }

    @Override
    public String getParamName() {
        return name;
    }

    @Override
    public Converter getConverter() {
        return converter;
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public void setValue(String value) throws Exception{
        log.debug("Trying to set value="+value);
        if(value.equals("")){
            this.value = "";
        }
        this.value = converter.convert(value);
    }

    @Override
    public String asUrlParam(String encoding) throws UnsupportedEncodingException {
        return name+"="+URLEncoder.encode(value, encoding);
    }

    
    
}
