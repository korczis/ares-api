/*
 * Copyright (C) 2011 xjuraj
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.multithreaddownloader.concurrency;

import org.apache.log4j.Logger;
import sk.lieskove.jianghongtiao.common.utils.PropertiesUtils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.*;
import java.security.Permission;
import java.util.List;
import java.util.Map;

/**
 * 
 * @author xjuraj e-mail: jjurco.sk_gmail.com
 */
public class InterruptableHttpUrlConnection implements Serializable, TimerClient {
    
    private transient Logger log = Logger.getLogger(InterruptableHttpUrlConnection.class);
    private transient PropertiesUtils pu = new PropertiesUtils(InterruptableHttpUrlConnection.class);
    
    private transient HttpURLConnection connection;

    public InterruptableHttpUrlConnection(HttpURLConnection connection) {
        this.connection = connection;
    }
    
    public HttpURLConnection getConnection(){
        return connection;
    }

    @Override
    public void timeLeft() {
        connection.disconnect();
    }
    
    @Override
    public String toString() {
        return connection.toString();
    }

    public void setUseCaches(boolean usecaches) {
        connection.setUseCaches(usecaches);
    }

    public void setRequestProperty(String key, String value) {
        connection.setRequestProperty(key, value);
    }

    public void setReadTimeout(int timeout) {
        connection.setReadTimeout(timeout);
    }

    public void setIfModifiedSince(long ifmodifiedsince) {
        connection.setIfModifiedSince(ifmodifiedsince);
    }

    public static void setFileNameMap(FileNameMap map) {
        HttpURLConnection.setFileNameMap(map);
    }

    public void setDoOutput(boolean dooutput) {
        connection.setDoOutput(dooutput);
    }

    public void setDoInput(boolean doinput) {
        connection.setDoInput(doinput);
    }

    public void setDefaultUseCaches(boolean defaultusecaches) {
        connection.setDefaultUseCaches(defaultusecaches);
    }

    public static void setDefaultAllowUserInteraction(boolean defaultallowuserinteraction) {
        HttpURLConnection.setDefaultAllowUserInteraction(defaultallowuserinteraction);
    }

    public static synchronized void setContentHandlerFactory(ContentHandlerFactory fac) {
        HttpURLConnection.setContentHandlerFactory(fac);
    }

    public void setConnectTimeout(int timeout) {
        connection.setConnectTimeout(timeout);
    }

    public void setAllowUserInteraction(boolean allowuserinteraction) {
        connection.setAllowUserInteraction(allowuserinteraction);
    }

    public static String guessContentTypeFromStream(InputStream is) throws IOException {
        return HttpURLConnection.guessContentTypeFromStream(is);
    }

    public static String guessContentTypeFromName(String fname) {
        return HttpURLConnection.guessContentTypeFromName(fname);
    }

    public boolean getUseCaches() {
        return connection.getUseCaches();
    }

    public URL getURL() {
        return connection.getURL();
    }

    public String getRequestProperty(String key) {
        return connection.getRequestProperty(key);
    }

    public Map<String, List<String>> getRequestProperties() {
        return connection.getRequestProperties();
    }

    public int getReadTimeout() {
        return connection.getReadTimeout();
    }

    public OutputStream getOutputStream() throws IOException {
        return connection.getOutputStream();
    }

    public long getLastModified() {
        return connection.getLastModified();
    }

    public InputStream getInputStream() throws IOException {
        return connection.getInputStream();
    }

    public long getIfModifiedSince() {
        return connection.getIfModifiedSince();
    }

    public Map<String, List<String>> getHeaderFields() {
        return connection.getHeaderFields();
    }

    public long getHeaderFieldLong(String name, long Default) {
        return connection.getHeaderFieldLong(name, Default);
    }

    public int getHeaderFieldInt(String name, int Default) {
        return connection.getHeaderFieldInt(name, Default);
    }

    public String getHeaderField(String name) {
        return connection.getHeaderField(name);
    }

    public static synchronized FileNameMap getFileNameMap() {
        return HttpURLConnection.getFileNameMap();
    }

    public long getExpiration() {
        return connection.getExpiration();
    }

    public boolean getDoOutput() {
        return connection.getDoOutput();
    }

    public boolean getDoInput() {
        return connection.getDoInput();
    }

    public boolean getDefaultUseCaches() {
        return connection.getDefaultUseCaches();
    }

    public static boolean getDefaultAllowUserInteraction() {
        return HttpURLConnection.getDefaultAllowUserInteraction();
    }

    public long getDate() {
        return connection.getDate();
    }

    public String getContentType() {
        return connection.getContentType();
    }

    public long getContentLengthLong() {
        return connection.getContentLengthLong();
    }

    public int getContentLength() {
        return connection.getContentLength();
    }

    public String getContentEncoding() {
        return connection.getContentEncoding();
    }

    public Object getContent(Class[] classes) throws IOException {
        return connection.getContent(classes);
    }

    public Object getContent() throws IOException {
        return connection.getContent();
    }

    public int getConnectTimeout() {
        return connection.getConnectTimeout();
    }

    public boolean getAllowUserInteraction() {
        return connection.getAllowUserInteraction();
    }

    public void connect() throws IOException {
        connection.connect();
    }

    public void addRequestProperty(String key, String value) {
        connection.addRequestProperty(key, value);
    }

    public boolean usingProxy() {
        return connection.usingProxy();
    }

    public void setRequestMethod(String method) throws ProtocolException {
        connection.setRequestMethod(method);
    }

    public void setInstanceFollowRedirects(boolean followRedirects) {
        connection.setInstanceFollowRedirects(followRedirects);
    }

    public static void setFollowRedirects(boolean set) {
        HttpURLConnection.setFollowRedirects(set);
    }

    public void setFixedLengthStreamingMode(long contentLength) {
        connection.setFixedLengthStreamingMode(contentLength);
    }

    public void setFixedLengthStreamingMode(int contentLength) {
        connection.setFixedLengthStreamingMode(contentLength);
    }

    public void setChunkedStreamingMode(int chunklen) {
        connection.setChunkedStreamingMode(chunklen);
    }

    public String getResponseMessage() throws IOException {
        return connection.getResponseMessage();
    }

    public int getResponseCode() throws IOException {
        return connection.getResponseCode();
    }

    public String getRequestMethod() {
        return connection.getRequestMethod();
    }

    public Permission getPermission() throws IOException {
        return connection.getPermission();
    }

    public boolean getInstanceFollowRedirects() {
        return connection.getInstanceFollowRedirects();
    }

    public String getHeaderFieldKey(int n) {
        return connection.getHeaderFieldKey(n);
    }

    public long getHeaderFieldDate(String name, long Default) {
        return connection.getHeaderFieldDate(name, Default);
    }

    public String getHeaderField(int n) {
        return connection.getHeaderField(n);
    }

    public static boolean getFollowRedirects() {
        return HttpURLConnection.getFollowRedirects();
    }

    public InputStream getErrorStream() {
        return connection.getErrorStream();
    }

    public void disconnect() {
        connection.disconnect();
    }

}
