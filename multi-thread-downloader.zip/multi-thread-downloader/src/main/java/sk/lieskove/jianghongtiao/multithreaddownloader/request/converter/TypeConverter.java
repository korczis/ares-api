/*
 * Copyright (C) 2011 JiangHongTiao
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.multithreaddownloader.request.converter;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;

/**
 * Date of create: May 20, 2011
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 * @version 2011.0520
 */
public class TypeConverter implements Converter{
    
    private String type;
    Logger log = Logger.getLogger(LengthRangeConverter.class.getName());

    public TypeConverter(String type) {
        log.debug("TypeConverter created with type="+type);
        if(type == null){
            throw new NullPointerException("Type is null!");
        }
        this.type = type;
    }

    /**
     * date - a String object representing a date in in the format "yyyy-mm-dd"
     * @param value - string representation of value to check
     * @return converted value
     * @throws Exception if value is not in given format
     */
    @Override
    public String convert(String value) throws Exception {
        log.debug("TypeConverter convert with type="+type+" value:"+value);
        value = value.toLowerCase();
        if(type.equals("short")){
            Short.parseShort(value);
        }
        if(type.equals("int") || type.equals("integer")){
            Integer.parseInt(value);
        }
        if(type.equals("double")){
            Double.parseDouble(value);
        }
        if(type.equals("float")){
            Float.parseFloat(value);
        }
        if(type.equals("date")){
            DateTime dt = new DateTime(value);
            value = dt.toString("dd.MM.yyyy");
        }
        if(value.equals("boolean") || value.equals("bool")){
            if(value.equals("a") || value.equals("ano") || value.equals("y") || 
                    value.equals("yes") || Boolean.parseBoolean(value)){
                return "A";
            }
            if(value.equals("n") || value.equals("ne") || value.equals("no") || 
                     !Boolean.parseBoolean(value)){
                return "N";
            }
        }
        if(value.equals("en-boolean") || value.equals("en-bool")){
            if(value.equals("a") || value.equals("ano") || value.equals("y") || 
                    value.equals("yes") || Boolean.parseBoolean(value)){
                return "true";
            }
            if(value.equals("n") || value.equals("ne") || value.equals("no") || 
                     !Boolean.parseBoolean(value)){
                return "false";
            }
        }
        return value;
    }
    
}
