/*
 * Copyright (C) 2011 JiangHongTiao
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.multithreaddownloader.request.converter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Date of create: May 20, 2011
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 * @version 2011.0520
 */
public class RegExpConverter implements Converter{
    
    public static final String VERSION_REGEPX = "\\d\\.\\d\\.\\d";
    public static final String ICO_REGEPX = "\\d{8}";
    
    private Pattern pattern;

    public RegExpConverter(String regExp) {
        if((regExp == null) || (regExp.equals(""))){
            throw new IllegalArgumentException("Regular Expression cannot be null or empty!");
        }
        pattern = Pattern.compile(regExp, Pattern.CASE_INSENSITIVE);
    }

    @Override
    public String convert(String value) throws Exception {
        Matcher matcher = pattern.matcher(value);
        return matcher.group();
    }
    
}
