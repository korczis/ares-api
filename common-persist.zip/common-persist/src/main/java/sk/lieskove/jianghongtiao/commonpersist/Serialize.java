/*
 * Copyright (C) 2011 JiangHongTiao
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.commonpersist;

import org.apache.log4j.Logger;
import sk.lieskove.jianghongtiao.common.utils.PropertiesUtils;

import java.io.*;
import java.util.logging.Level;

/**
 *
 * @author xjuraj
 */
public class Serialize {
    private static PropertiesUtils pu = new PropertiesUtils(Persist.class);
    private static Logger log = Logger.getLogger(Persist.class.getName());

    public static void serialize(File file, Object object) {
        FileOutputStream f_out = null;
        {
            ObjectOutputStream obj_out = null;
            try {
                f_out = new FileOutputStream(file);
                obj_out = new ObjectOutputStream(f_out);
                obj_out.writeObject(object);
            } catch (FileNotFoundException ex) {
                log.error("File was not found! FileName: "+file.getAbsolutePath());
            } catch (IOException ex) {
                log.error("IO exception thrown while writing object to file: "+file.getAbsolutePath());
            } finally {
                try {
                    f_out.close();
                } catch (IOException ex) {
                    log.error("Exception thrown while closing file: "+file.getAbsolutePath());
                }
                try {
                    obj_out.close();
                } catch (IOException ex) {
                    log.error("Cannot close Object output stream: "+file.getAbsolutePath());
                }
            }
        }
    }
    
    public static Object deserialize(File file, Class classType){
        Object output = null;
        FileInputStream fis = null;
        {
            ObjectInputStream ois = null;
            try {
                fis = new FileInputStream(file);
                ois = new ObjectInputStream(fis);
                output = classType.cast(ois.readObject());
            } catch (FileNotFoundException ex) {
               java.util.logging.Logger.getLogger(Serialize.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                java.util.logging.Logger.getLogger(Serialize.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                java.util.logging.Logger.getLogger(Serialize.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                try {
                    fis.close();
                } catch (IOException ex) {
                    java.util.logging.Logger.getLogger(Serialize.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    ois.close();
                } catch (IOException ex) {
                    java.util.logging.Logger.getLogger(Serialize.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        return output;
    }
}
