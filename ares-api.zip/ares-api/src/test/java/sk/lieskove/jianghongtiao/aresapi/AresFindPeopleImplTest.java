/*
 *  Copyright (C) 2011 JiangHongTiao <jjurco.sk_gmail.com>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.aresapi;

import junit.framework.TestCase;
import org.joda.time.IllegalFieldValueException;
import sk.lieskove.jianghongtiao.aresapi.websearch.AresFindPeople;
import sk.lieskove.jianghongtiao.aresapi.websearch.AresFindPeopleImpl;
import sk.lieskove.jianghongtiao.aresapi.websearch.NoParameterSet;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Date of create: May 15, 2011
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 * @version 2011.0515
 */
public class AresFindPeopleImplTest extends TestCase {
    
    private String URL_ENC="iso-8859-2";

    public AresFindPeopleImplTest(String testName) {
        super(testName);
    }

    @Override
    protected void setUp() throws Exception {
        super.setUp();
    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    /**
     * Test of setAdresa method, of class AresFindPeopleImpl.
     */
    public void testSetAdresa() {
        System.out.println("setAdresa");
        AresFindPeopleImpl instance = new AresFindPeopleImpl();
        //empty address
        String adresa = "";
        instance.setAdresa(adresa);
        adresa = null;
        instance.setAdresa(adresa);
        //lng 45
        adresa = "012345678912345012345678912345012345678912345";
        instance.setAdresa(adresa);
        //any lng
        adresa = "012345678912345012345678912345";
        instance.setAdresa(adresa);

        try {
            //len 46
            adresa = "0123456789123450123456789123450123456789123456";
            instance.setAdresa(adresa);
            fail("Cis_or accepts: 1zz");
        } catch (IllegalArgumentException e) {
        }
    }

    /**
     * Test of setCis_or method, of class AresFindPeopleImpl.
     */
    public void testSetCis_or() {
        System.out.println("setCis_or");
        AresFindPeopleImpl instance = new AresFindPeopleImpl();
        String cis_or = "1";
        instance.setCis_or(cis_or);
        cis_or = "999";
        instance.setCis_or(cis_or);
        cis_or = "1a";
        instance.setCis_or(cis_or);
        cis_or = "999a";
        instance.setCis_or(cis_or);
        cis_or = "1z";
        instance.setCis_or(cis_or);
        cis_or = "999z";
        instance.setCis_or(cis_or);
        cis_or = "";
        instance.setCis_or(cis_or);
        cis_or = null;
        instance.setCis_or(cis_or);

        try {
            cis_or = "9999";
            instance.setCis_or(cis_or);
            fail("Cis_or accepts: 9999");
        } catch (IllegalArgumentException e) {
        }
        try {
            cis_or = "1a1";
            instance.setCis_or(cis_or);
            fail("Cis_or accepts: 1a1");
        } catch (IllegalArgumentException e) {
        }
        try {
            cis_or = "999aa";
            instance.setCis_or(cis_or);
            fail("Cis_or accepts: 999aa");
        } catch (IllegalArgumentException e) {
        }
        try {
            cis_or = "1zz";
            instance.setCis_or(cis_or);
            fail("Cis_or accepts: 1zz");
        } catch (IllegalArgumentException e) {
        }
        try {
            cis_or = "z999";
            instance.setCis_or(cis_or);
            fail("Cis_or accepts: z999");
        } catch (IllegalArgumentException e) {
        }
    }

    /**
     * Test of setCis_po method, of class AresFindPeopleImpl.
     */
    public void testSetCis_po() {
        System.out.println("setCis_po");
        AresFindPeopleImpl instance = new AresFindPeopleImpl();
        String cis_po = "";
        instance.setCis_po(cis_po);
        cis_po = null;
        instance.setCis_po(cis_po);
        cis_po = "1";
        instance.setCis_po(cis_po);
        cis_po = "9999";
        instance.setCis_po(cis_po);
        try {
            cis_po = "z999";
            instance.setCis_po(cis_po);
            fail("Cis_po accepts: z999");
        } catch (IllegalArgumentException e) {
        }
        try {
            cis_po = "a";
            instance.setCis_po(cis_po);
            fail("Cis_po accepts: a");
        } catch (IllegalArgumentException e) {
        }
        try {
            cis_po = "10000";
            instance.setCis_po(cis_po);
            fail("Cis_po accepts: 10000");
        } catch (IllegalArgumentException e) {
        }
        try {
            cis_po = "0";
            instance.setCis_po(cis_po);
            fail("Cis_po accepts: 0");
        } catch (IllegalArgumentException e) {
        }
        try {
            cis_po = "99a9";
            instance.setCis_po(cis_po);
            fail("Cis_po accepts: 99a9");
        } catch (IllegalArgumentException e) {
        }
        try {
            cis_po = "999a";
            instance.setCis_po(cis_po);
            fail("Cis_po accepts: 999a");
        } catch (IllegalArgumentException e) {
        }
    }

    /**
     * Test of setJmeno method, of class AresFindPeopleImpl.
     */
    public void testSetJmeno() {
        System.out.println("setJmeno");
        AresFindPeopleImpl instance = new AresFindPeopleImpl();
        String jmeno = "";
        instance.setJmeno(jmeno);
        jmeno = null;
        instance.setJmeno(jmeno);
        jmeno = "pavel blabla";
        instance.setJmeno(jmeno);
        //length 25
        jmeno = "0123456789012345678912345";
        instance.setJmeno(jmeno);
        try {
            //length26
            jmeno = "01234567890123456789123456";
            instance.setJmeno(jmeno);
            fail("Name accepts string of length 26");
        } catch (IllegalArgumentException e) {
        }

    }

    /**
     * Test of setObec method, of class AresFindPeopleImpl.
     */
    public void testSetObec() {
        System.out.println("setObec");
        AresFindPeopleImpl instance = new AresFindPeopleImpl();
        String obec = "";
        instance.setObec(obec);
        obec = null;
        instance.setObec(obec);
        obec = "horna lucka";
        instance.setObec(obec);
        //length 45
        obec = "012345678901234567890123456789012345678912345";
        instance.setObec(obec);
        try {
            //length46
            obec = "0123456789012345678901234567890123456789123456";
            instance.setObec(obec);
            fail("Township accepts string of length 46");
        } catch (IllegalArgumentException e) {
        }
    }

    /**
     * Test of setPsc method, of class AresFindPeopleImpl.
     */
    public void testSetPsc() {
        System.out.println("setPsc");
        AresFindPeopleImpl instance = new AresFindPeopleImpl();
        String psc = "";
        instance.setPsc(psc);
        psc = "91305";
        instance.setPsc(psc);
        psc = "";
        instance.setPsc(psc);
        try {
            psc = "9999";
            instance.setPsc(psc);
            fail("PSC accepts: 9999");
        } catch (IllegalArgumentException ex) {
        }
        try {
            psc = "111111";
            instance.setPsc(psc);
            fail("PSC accepts: 111111");
        } catch (IllegalArgumentException ex) {
        }
        try {
            psc = "a";
            instance.setPsc(psc);
            fail("PSC accepts: a");
        } catch (IllegalArgumentException ex) {
        }
        try {
            psc = "aaaaa";
            instance.setPsc(psc);
            fail("PSC accepts: aaaaa");
        } catch (IllegalArgumentException ex) {
        }
        try {
            psc = "9999a";
            instance.setPsc(psc);
            fail("PSC accepts: 9999a");
        } catch (IllegalArgumentException ex) {
        }
    }

    /**
     * Test of setRc method, of class AresFindPeopleImpl.
     */
    public void testSetRc_String() {
        System.out.println("setRc");
//340621/026 - platné

        AresFindPeopleImpl instance = new AresFindPeopleImpl();
        String[] good = {
            "8706057525",
            "8706057570",
            "330622999",
            "9662319997"};
        for (int i = 0; i < good.length; i++) {
            String string = good[i];
            try {
                instance.setRc(string);
            } catch (Exception e) {
                fail("Thrown exception: " + e);
            }
        }

        String[] bad = {
            "125445000", //125448/000 - neplatné, duben má jen 30 dní
            "580931026",//580931/0452 - neplatné, září nemá 31 dní
            "6702291125",//670229/1125 - neplatné, rok 1967 nebyl přestupný
            "4153190554",//415319/0554 - platné, ale nenarodene - zle
            "585219066",//po roku 53 ale iba 9 miestne
            "8706057526"//neplatne posledne cislo
        };

        for (int i = 0; i < bad.length; i++) {
            String string = bad[i];
            try {
                instance.setRc(string);
                fail("Exception not thrown for: " + string);
            } catch (IllegalFieldValueException e) {
                System.out.println("Catched exception: " + e);
            } catch (Exception e) {
                System.out.println("Catched exception: " + e);
            }
        }
    }

    /**
     * Test of setRc method, of class AresFindPeopleImpl.
     */
    public void testSetRc_String_String() {
        System.out.println("setRc");
        AresFindPeopleImpl instance = new AresFindPeopleImpl();
        String[] good = {
            "870605",
            "870605",
            "330622",
            "966231"};
        String[] good2 = {
            "7525",
            "7570",
            "999",
            "9997"};
        for (int i = 0; i < good.length; i++) {
            try {
                instance.setRc(good[i], good2[i]);
            } catch (Exception e) {
                fail("Thrown exception: " + e);
            }
        }

        String[] bad = {
            "125445000", //125448/000 - neplatné, duben má jen 30 dní
            "580931026",//580931/0452 - neplatné, září nemá 31 dní
            "6702291125",//670229/1125 - neplatné, rok 1967 nebyl přestupný
            "4153190554",//415319/0554 - platné, ale nenarodene - zle
            "585219066",//po roku 53 ale iba 9 miestne
            "8706057526"//neplatne posledne cislo
        };
        String[] bad2 = {
            "000", //125448/000 - neplatné, duben má jen 30 dní
            "026",//580931/0452 - neplatné, září nemá 31 dní
            "1125",//670229/1125 - neplatné, rok 1967 nebyl přestupný
            "0554",//415319/0554 - platné, ale nenarodene - zle
            "066",//po roku 53 ale iba 9 miestne
            "7526"//neplatne posledne cislo
        };

        for (int i = 0; i < bad.length; i++) {
            try {
                instance.setRc(bad[i], bad2[i]);
                fail("Exception not thrown for: " + bad[i] + "/" + bad2[i]);
            } catch (IllegalFieldValueException e) {
                System.out.println("Catched exception: " + e);
            } catch (Exception e) {
                System.out.println("Catched exception: " + e);
            }

        }
    }

    public void testMakeURL() {
        System.out.println("MakeURL");
        AresFindPeopleImpl instance = new AresFindPeopleImpl();
        String baseUrl = "http://wwwinfo.mfcr.cz/cgi-bin/ares/ares_fo.cgi?";
        String diakritika = "ľščťžýáí éňäúôěřů-";
        String diakritikaEnc = "";
        try {
            diakritikaEnc = URLEncoder.encode(diakritika, URL_ENC);
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(AresFindPeopleImplTest.class.getName()).
                    log(Level.SEVERE, null, ex);
        }

        try {
            instance.makeUrl();
            fail("Make URL does not throws error without any parameter posted");
        } catch (NoParameterSet nps) {
            System.out.println("Catched exception: " + nps);
        }
        instance.setAdresa(diakritika);
        assertTrue("does not contains adresa=" + diakritikaEnc, instance.makeUrl().
                contains("adresa=" + diakritikaEnc));

        AresFindPeople.Angaz[] angaz = {AresFindPeople.Angaz.A_1800,
            AresFindPeople.Angaz.A_1801,
            AresFindPeople.Angaz.A_1802,
            AresFindPeople.Angaz.A_200,
            AresFindPeople.Angaz.A_201,
            AresFindPeople.Angaz.A_202,
            AresFindPeople.Angaz.A_203,
            AresFindPeople.Angaz.A_204,
            AresFindPeople.Angaz.A_205,
            AresFindPeople.Angaz.A_206,
            AresFindPeople.Angaz.A_207,
            AresFindPeople.Angaz.A_208,
            AresFindPeople.Angaz.A_209,
            AresFindPeople.Angaz.A_210,
            AresFindPeople.Angaz.A_211,
            AresFindPeople.Angaz.A_212,
            AresFindPeople.Angaz.A_214,
            AresFindPeople.Angaz.A_215,
            AresFindPeople.Angaz.A_219,
            AresFindPeople.Angaz.A_220,
            AresFindPeople.Angaz.A_221,
            AresFindPeople.Angaz.A_222,
            AresFindPeople.Angaz.A_223,
            AresFindPeople.Angaz.A_224,
            AresFindPeople.Angaz.A_225,
            AresFindPeople.Angaz.A_227,
            AresFindPeople.Angaz.A_228,
            AresFindPeople.Angaz.A_229,
            AresFindPeople.Angaz.A_230,
            AresFindPeople.Angaz.A_231,
            AresFindPeople.Angaz.A_232,
            AresFindPeople.Angaz.A_233,
            AresFindPeople.Angaz.A_234,
            AresFindPeople.Angaz.A_235,
            AresFindPeople.Angaz.A_236,
            AresFindPeople.Angaz.A_237,
            AresFindPeople.Angaz.A_238,
            AresFindPeople.Angaz.A_400,
            AresFindPeople.Angaz.A_401,
            AresFindPeople.Angaz.A_402,
            AresFindPeople.Angaz.A_402,
            AresFindPeople.Angaz.A_402};
        instance.setAngaz(angaz);
        try {
            instance.getAngaz();
        } catch (Exception e) {
            fail("Thrown exception while getting Angaz: " + e);
        }
        assertTrue("does not contains correct angaz url. Contains: " + instance.
                makeUrl(),
                instance.makeUrl().contains("angaz=200+201+202+203+"
                + "204+205+206+207+208+209+210+211+212+214+215+219+220+221+222+"
                + "223+224+225+227+228+229+230+231+232+233+234+235+236+237+238+400+"
                + "401+402+1800+1801+1802"));

        AresFindPeople.Angaz[] angaz1 = {AresFindPeople.Angaz.A_1800};
        instance.setAngaz(angaz1);
        assertTrue("does not contains correct angaz url. Contains: " + instance.
                makeUrl(),
                instance.makeUrl().contains("angaz=1800"));

        AresFindPeople.Angaz[] angaz2 = {};
        instance.setAngaz(angaz2);
        assertFalse("does not contains correct angaz url. Contains: " + instance.
                makeUrl(),
                instance.makeUrl().contains("angaz="));
        try {
            instance.setAngaz(null);
        } catch (Exception ex) {
            fail("SetAngaz(String) exception thrown: " + ex);
        }

        instance.setAngazma(AresFindPeople.Angazma.VYBER);
        try {
            assertTrue("Does not contains angazma 'výběr'. Url: " + instance.
                    makeUrl(),
                    instance.makeUrl().
                    contains("angazma=" + URLEncoder.encode("výběr", URL_ENC)));
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(AresFindPeopleImplTest.class.getName()).
                    log(Level.SEVERE, null, ex);
        }
        instance.setAngazma(AresFindPeople.Angazma.VSECHNA);
        try {
            assertTrue("Does not contains angazma 'všechna'. Url: " + instance.
                    makeUrl(),
                    instance.makeUrl().
                    contains("angazma=" + URLEncoder.encode("všechna", URL_ENC)));
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(AresFindPeopleImplTest.class.getName()).
                    log(Level.SEVERE, null, ex);
        }
        try {
            instance.setAngazma(null);
        } catch (Exception ex) {
            fail("SetAngazma(String) exception thrown: " + ex);
        }

        instance.setCestina(AresFindPeople.Diakritika.ASCII);
        assertTrue("Url does not contains 'cestina'. URL: " + instance.makeUrl(),
                instance.makeUrl().contains("cestina="));
        instance.setCestina(AresFindPeople.Diakritika.CESTINA);
        assertTrue("Url does not contains 'cestina'. URL: " + instance.makeUrl(),
                instance.makeUrl().contains("cestina=cestina"));
        try {
            instance.setCestina(null);
        } catch (Exception ex) {
            fail("SetCestina(String) exception thrown: " + ex);
        }

        instance.setCis_or("12");
        assertTrue("Does not contains Cis_or. URL: " + instance.makeUrl(),
                instance.makeUrl().contains("cis_or=12"));

        instance.setCis_po("12");
        assertTrue("Does not contains Cis_po. URL: " + instance.makeUrl(),
                instance.makeUrl().contains("cis_po=12"));
        try {
            instance.setCis_po("");
            instance.setCis_po(null);
        } catch (Exception ex) {
            fail("SetCis_po(String) exception thrown: " + ex);
        }

        instance.setJazyk(AresFindPeople.Jazyk.CZ);
        assertTrue("Does not contains jazyk=CZ" + instance.makeUrl(),
                instance.makeUrl().contains("jazyk=CZ"));
        instance.setJazyk(AresFindPeople.Jazyk.EN);
        assertTrue("Does not contains jazyk=EN. URL: " + instance.makeUrl(),
                instance.makeUrl().contains("jazyk=EN"));
        try {
            instance.setJazyk(null);
        } catch (Exception ex) {
            fail("SetJazyk(String) exception thrown: " + ex);
        }

        instance.setJmeno(diakritika);
        assertTrue("jmeno is not correct. URL: " + instance.makeUrl(),
                instance.makeUrl().contains("jmeno=" + diakritikaEnc));
        try {
            instance.setJmeno("");
            instance.setJmeno(null);
        } catch (Exception ex) {
            fail("SetJmeno(String) exception thrown: " + ex);
        }

        instance.setMaxpoc(AresFindPeople.MaxPoc.MAX_200);
        assertTrue("maxpoc with 200 is not correct. URL: " + instance.makeUrl(),
                instance.makeUrl().contains("maxpoc=200"));
        instance.setMaxpoc(AresFindPeople.MaxPoc.MAX_500);
        assertTrue("maxpoc with 500 is not correct. URL: " + instance.makeUrl(),
                instance.makeUrl().contains("maxpoc=500"));
        instance.setMaxpoc(AresFindPeople.MaxPoc.MAX_1000);
        assertTrue("maxpoc with 1000 is not correct. URL: " + instance.makeUrl(),
                instance.makeUrl().contains("maxpoc=1000"));
        try {
            instance.setMaxpoc(null);
        } catch (Exception ex) {
            fail("SetMaxpoc(String) exception thrown: " + ex);
        }

        instance.setObec(diakritika);
        assertTrue("obec is not correct. URL: " + instance.makeUrl(),
                instance.makeUrl().contains("obec=" + diakritikaEnc));
        try {
            instance.setObec("");
            instance.setObec(null);
        } catch (Exception ex) {
            fail("SetObec(String) exception thrown: " + ex);
        }

        instance.setPsc("12345");
        assertTrue("psc is not correct. URL: " + instance.makeUrl(),
                instance.makeUrl().contains("psc=12345"));
        try {
            instance.setPsc("");
            instance.setPsc(null);
        } catch (Exception ex) {
            fail("SetPsc(String) exception thrown: " + ex);
        }

        instance.setRc("8706057525");
        assertTrue("rc is not correct. URL: " + instance.makeUrl(),
                instance.makeUrl().contains("rc=8706057525"));
        try {
            instance.setRc("");
            instance.setRc(null);
        } catch (Exception ex) {
            fail("SetRc(String) exception thrown: " + ex);
        }

        instance.setRc("870605", "7525");
        assertTrue("rc is not correct. URL: " + instance.makeUrl(),
                instance.makeUrl().contains("rc=8706057525"));
        try {
            instance.setRc("", "");
            instance.setRc(null, null);
        } catch (Exception ex) {
            fail("SetRc(String, String) exception thrown: " + ex);
        }

        instance.setSetrid(AresFindPeople.Setrid.ZADNE);
        assertTrue("setrid ZADNE is not correct. URL: " + instance.makeUrl(),
                instance.makeUrl().contains("setrid=ZADNE"));
        instance.setSetrid(AresFindPeople.Setrid.RC);
        assertTrue("setrid RC is not correct. URL: " + instance.makeUrl(),
                instance.makeUrl().contains("setrid=RC"));
        instance.setSetrid(AresFindPeople.Setrid.JMENO);
        assertTrue("setrid JMENO is not correct. URL: " + instance.makeUrl(),
                instance.makeUrl().contains("setrid=JMENO"));
        try {
            instance.setSetrid(null);
        } catch (Exception ex) {
            fail("SetSetrid(String) exception thrown: " + ex);
        }
        try {
            instance.setAdresa("");
            instance.setAdresa(null);
        } catch (Exception ex) {
            fail("SetAdresa(String) exception thrown: " + ex);
        }
    }
}
