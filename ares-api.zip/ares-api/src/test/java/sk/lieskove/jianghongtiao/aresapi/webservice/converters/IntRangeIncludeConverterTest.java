/*
 * Copyright (C) 2011 JiangHongTiao
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.aresapi.webservice.converters;

import junit.framework.TestCase;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.converter.IntRangeIncludeConverter;

/**
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 */
public class IntRangeIncludeConverterTest extends TestCase {
    
    public IntRangeIncludeConverterTest(String testName) {
        super(testName);
    }
    
    @Override
    protected void setUp() throws Exception {
        super.setUp();
    }
    
    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    /**
     * Test of convert method, of class IntRangeIncludeConverter.
     */
    public void testConvert() throws Exception {
        System.out.println("convert");
        String value = "10";
        String expResult = value;
        IntRangeIncludeConverter instance = new IntRangeIncludeConverter(10, 15);
        String result = instance.convert(value);
        assertEquals(expResult, result);
        
        value = "15";
        expResult = value;
        instance = new IntRangeIncludeConverter(10, 15);
        result = instance.convert(value);
        assertEquals(expResult, result);
        
        value = "12";
        expResult = value;
        instance = new IntRangeIncludeConverter(10, 15);
        result = instance.convert(value);
        assertEquals(expResult, result);
        
        value = "-55506946";
        expResult = value;
        instance = new IntRangeIncludeConverter(null, 15);
        result = instance.convert(value);
        assertEquals(expResult, result);
        
        value = "15";
        expResult = value;
        instance = new IntRangeIncludeConverter(null, 15);
        result = instance.convert(value);
        assertEquals(expResult, result);
        
        value = "15654650";
        expResult = value;
        instance = new IntRangeIncludeConverter(10, null);
        result = instance.convert(value);
        assertEquals(expResult, result);
        
        value = "10";
        expResult = value;
        instance = new IntRangeIncludeConverter(10, null);
        result = instance.convert(value);
        assertEquals(expResult, result);
        
        try {
            instance = new IntRangeIncludeConverter(null, null);
            fail("Exception was not thrown!");
        } catch (Exception e) {
        }
    }
}
