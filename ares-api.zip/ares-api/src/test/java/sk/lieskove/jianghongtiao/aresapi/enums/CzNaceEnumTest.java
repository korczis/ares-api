/*
 * Copyright (C) 2011 JiangHongTiao
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.aresapi.enums;

import junit.framework.TestCase;

/**
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 */
public class CzNaceEnumTest extends TestCase {

    public CzNaceEnumTest(String testName) {
        super(testName);
    }

    @Override
    protected void setUp() throws Exception {
        super.setUp();
    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    /**
     * Test of values method, of class CzNaceEnum.
     */
    public void testValues() {
        System.out.println("values");
        CzNaceEnum[] expResult = new CzNaceEnum[]{CzNaceEnum.CZNACE_000000,
            CzNaceEnum.CZNACE_010000, CzNaceEnum.CZNACE_020000,
            CzNaceEnum.CZNACE_030000, CzNaceEnum.CZNACE_050000,
            CzNaceEnum.CZNACE_060000, CzNaceEnum.CZNACE_070000,
            CzNaceEnum.CZNACE_080000, CzNaceEnum.CZNACE_090000,
            CzNaceEnum.CZNACE_100000, CzNaceEnum.CZNACE_110000,
            CzNaceEnum.CZNACE_120000, CzNaceEnum.CZNACE_130000,
            CzNaceEnum.CZNACE_140000, CzNaceEnum.CZNACE_150000,
            CzNaceEnum.CZNACE_160000, CzNaceEnum.CZNACE_170000,
            CzNaceEnum.CZNACE_180000, CzNaceEnum.CZNACE_190000,
            CzNaceEnum.CZNACE_200000, CzNaceEnum.CZNACE_210000,
            CzNaceEnum.CZNACE_220000, CzNaceEnum.CZNACE_230000,
            CzNaceEnum.CZNACE_240000, CzNaceEnum.CZNACE_250000,
            CzNaceEnum.CZNACE_260000, CzNaceEnum.CZNACE_270000,
            CzNaceEnum.CZNACE_280000, CzNaceEnum.CZNACE_290000,
            CzNaceEnum.CZNACE_300000, CzNaceEnum.CZNACE_310000,
            CzNaceEnum.CZNACE_320000, CzNaceEnum.CZNACE_330000,
            CzNaceEnum.CZNACE_350000, CzNaceEnum.CZNACE_360000,
            CzNaceEnum.CZNACE_370000, CzNaceEnum.CZNACE_380000,
            CzNaceEnum.CZNACE_390000, CzNaceEnum.CZNACE_410000,
            CzNaceEnum.CZNACE_420000, CzNaceEnum.CZNACE_430000,
            CzNaceEnum.CZNACE_450000, CzNaceEnum.CZNACE_460000,
            CzNaceEnum.CZNACE_470000, CzNaceEnum.CZNACE_490000,
            CzNaceEnum.CZNACE_500000, CzNaceEnum.CZNACE_510000,
            CzNaceEnum.CZNACE_520000, CzNaceEnum.CZNACE_530000,
            CzNaceEnum.CZNACE_550000, CzNaceEnum.CZNACE_560000,
            CzNaceEnum.CZNACE_580000, CzNaceEnum.CZNACE_590000,
            CzNaceEnum.CZNACE_600000, CzNaceEnum.CZNACE_610000,
            CzNaceEnum.CZNACE_620000, CzNaceEnum.CZNACE_630000,
            CzNaceEnum.CZNACE_640000, CzNaceEnum.CZNACE_650000,
            CzNaceEnum.CZNACE_660000, CzNaceEnum.CZNACE_680000,
            CzNaceEnum.CZNACE_690000, CzNaceEnum.CZNACE_700000,
            CzNaceEnum.CZNACE_710000, CzNaceEnum.CZNACE_720000,
            CzNaceEnum.CZNACE_730000, CzNaceEnum.CZNACE_740000,
            CzNaceEnum.CZNACE_750000, CzNaceEnum.CZNACE_770000,
            CzNaceEnum.CZNACE_780000, CzNaceEnum.CZNACE_790000,
            CzNaceEnum.CZNACE_800000, CzNaceEnum.CZNACE_810000,
            CzNaceEnum.CZNACE_820000, CzNaceEnum.CZNACE_840000,
            CzNaceEnum.CZNACE_850000, CzNaceEnum.CZNACE_860000,
            CzNaceEnum.CZNACE_870000, CzNaceEnum.CZNACE_880000,
            CzNaceEnum.CZNACE_900000, CzNaceEnum.CZNACE_910000,
            CzNaceEnum.CZNACE_920000, CzNaceEnum.CZNACE_930000,
            CzNaceEnum.CZNACE_940000, CzNaceEnum.CZNACE_950000,
            CzNaceEnum.CZNACE_960000, CzNaceEnum.CZNACE_970000,
            CzNaceEnum.CZNACE_980000};
        CzNaceEnum[] result = CzNaceEnum.values();
        boolean found = false;
        for (int i = 0; i < expResult.length; i++) {
            CzNaceEnum czNaceEnum = expResult[i];
            found = false;
            for (int j = 0; j < result.length; j++) {
                if(czNaceEnum.code().equals(result[j].code())){
                    found = true;
                    break;
                }
            }
            if(!found){
                fail("Result does not contains element: " + result[i].toString());
            }
        }
    }

    /**
     * Test of value method, of class CzNaceEnum.
     */
    public void testValue() {
        System.out.println("value");
        CzNaceEnum instance = CzNaceEnum.CZNACE_000000;
        String expResult = "000000";
        String result = instance.value();
        assertEquals(expResult, result);
    }

    /**
     * Test of fromValue method, of class CzNaceEnum.
     */
    public void testFromValue() {
        System.out.println("fromValue");
        String v = "020000";
        CzNaceEnum instance = CzNaceEnum.CZNACE_110000;
        CzNaceEnum expResult = CzNaceEnum.CZNACE_020000;
        CzNaceEnum result = instance.fromValue(v);
        assertEquals(expResult, result);
    }

    /**
     * Test of containsValue method, of class CzNaceEnum.
     */
    public void testContainsValue() {
        System.out.println("containsValue");
        String v = "020000";
        CzNaceEnum instance = CzNaceEnum.CZNACE_110000;
        boolean result = instance.containsValue(v);
        assertTrue(result);
        v = "0200000";
        instance = CzNaceEnum.CZNACE_020000;
        result = instance.containsValue(v);
        assertFalse(result);
    }
}
