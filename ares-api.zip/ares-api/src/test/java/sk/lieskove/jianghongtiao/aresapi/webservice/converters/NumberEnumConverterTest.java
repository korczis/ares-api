/*
 * Copyright (C) 2011 JiangHongTiao
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.aresapi.webservice.converters;

import junit.framework.TestCase;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.converter.NumberEnumConverter;

/**
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 */
public class NumberEnumConverterTest extends TestCase {
    
    public NumberEnumConverterTest(String testName) {
        super(testName);
    }
    
    @Override
    protected void setUp() throws Exception {
        super.setUp();
    }
    
    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    /**
     * Test of convert method, of class NumberEnumConverter.
     */
    public void testConvert() throws Exception {
        System.out.println("convert");
        String value = "1";
        String expResult = value;
        NumberEnumConverter instance = new NumberEnumConverter("integer", new String[]{"1", "2"});
        String result = instance.convert(value);
        assertEquals(expResult, result);
        
        value = "2";
        expResult = value;
        instance = new NumberEnumConverter("integer", new String[]{"1", "2"});
        result = instance.convert(value);
        assertEquals(expResult, result);
        
        value = "3";
        expResult = value;
        instance = new NumberEnumConverter("integer", new String[]{"1", "2"});
        try {
            result = instance.convert(value);
            fail("Exception was not thrown!");
        } catch (Exception e) {
        }
        
        value = "1.0";
        expResult = value;
        instance = new NumberEnumConverter("double", new String[]{"1.0", "2.2", "3.0"});
        result = instance.convert(value);
        assertEquals(expResult, result);
        
        value = "2.2";
        expResult = value;
        result = instance.convert(value);
        assertEquals(expResult, result);
        
        value = "3";
        expResult = value;
        result = instance.convert(value);
        assertEquals(expResult, result);
        
        value = "4";
        expResult = value;
        try {
            result = instance.convert(value);
            fail("Exception was not thrown!");
        } catch (Exception e) {
        }
        
    }
}
