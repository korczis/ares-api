/*
 * Copyright (C) 2011 JiangHongTiao
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.aresapi.webservice.converters;

import junit.framework.TestCase;
import sk.lieskove.jianghongtiao.aresapi.enums.CzNaceEnum;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.converter.EnumConverter;

/**
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 */
public class EnumConverterTest extends TestCase {
    
    public EnumConverterTest(String testName) {
        super(testName);
    }
    
    @Override
    protected void setUp() throws Exception {
        super.setUp();
    }
    
    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    /**
     * Test of convert method, of class EnumConverter.
     */
    public void testConvert() throws Exception {
        System.out.println("convert");
        String value = "980000";
        EnumConverter instance = new EnumConverter(CzNaceEnum.CZNACE_000000);
        String expResult = "980000";
        String result = instance.convert(value);
        assertEquals(expResult, result);
        value = "9800000";
        instance = new EnumConverter(CzNaceEnum.CZNACE_000000);
        try {
            result = instance.convert(value);
            fail("Exception was not thrown!");
        } catch (Exception e) {
        }
        
        
    }
}
