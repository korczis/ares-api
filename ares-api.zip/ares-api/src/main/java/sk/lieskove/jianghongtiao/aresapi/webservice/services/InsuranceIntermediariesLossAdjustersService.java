/*
 * Copyright (C) 2011 JiangHongTiao
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.aresapi.webservice.services;

import org.apache.log4j.Logger;
import sk.lieskove.jianghongtiao.aresapi.enums.Jazyk;
import sk.lieskove.jianghongtiao.aresapi.enums.VersionEnum;
import sk.lieskove.jianghongtiao.aresapi.enums.Xml;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.converter.*;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.exceptions.ParameterNotAllowedException;

import java.util.HashMap;
import java.util.Map;

/**
 * <h3>Input</h3>
 *      obligatory parameter:
 *      <br /><code>ico</code>
 *      <p>parameters:
 *      <table class="TInvisible">
 *       <tr><td class="PAlignRight"><code>ico</code></td><td> - Reg.No. is an identification number under which the entity is registered
 *       in the Commercial Register.
 *       The parameter is numerical, its maximum length is 8 digits. There is no need to enter the leading zeroes.
 *	</td></tr>
 *
 *       <tr><td class="PAlignRight"><code>rozsah</code></td><td>
 *          <code>=0</code> - a basic data output (default value)<br />
 *          <code>=1</code> - the complete data output of all data, including a complete history of the entity<br />
 *          <code>=2</code> - the current data output on the specified date, which is defined by parameter <code>datum_platnosti</code></td></tr>
 *
 *       <tr><td class="PAlignRight"><code>registracni_cislo</code></td><td>
 *          Registration number in ISPOZ. Min length is 8, max length is 12
 *       </td></tr>
 *
 *       <tr><td class="PAlignRight"><code>xml</code></td><td>
 *          <code>=0</code> - xml (default value)<br />
 *
 *          <code>=1</code> - html, transformation performed in browser on user's PC<br />
 *          <code>=2</code> - html, transformation from xml performed on server</td></tr>
 *       <tr><td class="PAlignRight"><code>jazyk</code></td><td> - defines the text of html pages<br />
 *          <code>=cz</code> - html in Czech (default value)<br />
 *
 *    		  <code>=en</code> - html in English</td></tr>
 *       <tr><td class="PAlignRight"><code>ver</code></td><td> - defines the xml output version (For details see <a href="ares_xml_get.html.en">Notes and recommendations</a>)<br />
 *          <code>=1.0.3</code> - economy-sized xml with element names in abbreviations (default value)<br />
 *
 *	  <code>=1.0.0</code> - version with full names of the elements</td><br />
 *       </tr>
 *       </table>
 *
 * Date of create: May 23, 2011
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 * @version 2011.0523
 */
public class InsuranceIntermediariesLossAdjustersService extends EmptyService {
    
    
    private final Map<String, Converter> converters = new HashMap<String, Converter>();
    private Logger log = Logger.getLogger(this.getClass().getName());

    public InsuranceIntermediariesLossAdjustersService() {
        log.debug("Creating "+this.getClass().getSimpleName()+" service!");
        String[] ver = new String[]{"1.0.0", "1.0.3"};
        converters.put("ico", new RegExpConverter(RegExpConverter.ICO_REGEPX));
        converters.put("xml", new EnumConverter(Xml.XML));
        converters.put("jazyk", new EnumConverter(Jazyk.EN));
        converters.put("ver", new StringEnumConverter(ver));
        converters.put("rozsah", new NumberEnumConverter("integer", new String[]{"0", "1", "2"}));
        converters.put("registracni_cislo", new LengthRangeConverter(8, 12));
        setConverters(converters);
        setObligatory(new String[]{"ico"});
        setOneOf(new String[]{});
        
        try {
            putParam("xml", "0");
            putParam("jazyk", Jazyk.EN.value());
        } catch (ParameterNotAllowedException ex) {
            log.error("Thrown unexpected exception. This never happened!" + ex);
        }
        
        setServiceUrl("http://wwwinfo.mfcr.cz/cgi-bin/ares/darv_poz.cgi");
        log.debug(this.getClass().getSimpleName()+" service created!");
    }
    
    public InsuranceIntermediariesLossAdjustersService(VersionEnum version){
        this();
        try {
            putParam("ver", version.value());
        } catch (ParameterNotAllowedException ex) {
            log.error("Thrown unexpected exception. This never happened!" + ex);
        }
    }
    
}
