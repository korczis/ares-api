/*
 * Copyright (C) 2011 JiangHongTiao
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.aresapi.webservice.services;

import org.apache.log4j.Logger;
import sk.lieskove.jianghongtiao.aresapi.enums.Jazyk;
import sk.lieskove.jianghongtiao.aresapi.enums.VersionEnum;
import sk.lieskove.jianghongtiao.aresapi.enums.Xml;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.converter.*;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.exceptions.ParameterNotAllowedException;

import java.util.HashMap;
import java.util.Map;

/**
 * A basic output from more registers.
 * <h3>Input</h3>
 * obligatory parameter:<code>ico</code>
 *<p>Other parameters:
 *<table class="TInvisible">
 *    
 * <tr><td class="PAlignRight"><code>ico</code></td><td> - 
 * Reg.No. is an identification number under which the entity is registered
 * in the Register of Economic Entities kept by the Czech Statistical Office.
 * The parameter is numerical, its maximum length is 8 digits. There is no need 
 * to enter the leading zeroes.
 * </td></tr>
 *
 *<tr><td class="PAlignRight"><code>xml</code></td><td>
 *<code>=0</code> - xml (default value)<br>
 *<code>=1</code> - html, transformation performed in browser on user's PC<br>
 *<code>=2</code> - html, transformation from xml performed on server</td></tr>
 *
 *<tr><td class="PAlignRight"><code>jazyk</code></td><td> - defines the text of html pages<br />
 *<code>=cz</code> - html in Czech (default value)<br>
 *<code>=en</code> - html in English</td></tr>
 *
 *<tr><td class="PAlignRight"><code>ver</code></td><td> - defines the xml output version (For details see <a href="ares_xml_get.html.en">Notes and recommendations</a>)<br />
 *
 *<code>=1.0.3</code> - economy-sized xml with element names in abbreviations (default value)<br>
 *<code>=1.0.2</code> - version with full names of the elements</td></tr>
 *
 *<tr><td class="PAlignRight"><code>aktivni</code></td><td> - defines the entity's ouput according to its activity<br />
 *<code>=true</code> - output available only for an active entity (default value)<br />
 *
 *<code>=false</code> - output available even for a defunct entity (deregistration)</td></tr>
 *
 *<tr><td class="PAlignRight">
 *<code>adr_puv</code></td><td> - 
 *extends data output by an element <span class="XMLe">Adr_puv</span> containing the original address from the data source without the process of address standardization.
 *(For details of the output address elements see <b>OutpA basic output from more registers.ut</b>.)
 *</cz><br />
 *<code>=true</code> - data output including the element <span class="XMLe">Adr_puv</span><br />
 *
 *<code>=false</code> - data output without the element <span class="XMLe">Adr_puv</span> (default value)
 *</td></tr>
 *</table>
 *</p><br />
 *
 *      <h3>Output</h3><br />
 *      <p>The Basic service displays basic information selected from more source registers. The basic data (Reg.No., Business name, Legal form, Address)  comes from the ARES core, i.e. from one of the sources defined as a priority source for the entity. The entity's Date of establishment and Date of termination come also from the priority source. Some elements contain information on the source from which the data comes.</p>
 *      <p>The element <span class="XMLe">Datum_vzniku</span> contains the date the meaning of which may differ in dependence on a type of the register. In the sources RES, AGC, RCRS, the said element contains the entity's Date of establishment or Date of registration, in CR it means Record date, in TR it means the date of registration of the first trade. The same it is with the element <span class="XMLe">Datum_zaniku</span> when in CR it means the date of entity's deletion from CR. To gain information on the entity's date of establishment or termination in individual source registers, use the option A query for a list of entity's registrations in the source registers (Seznam_Reg service).</p>
 *
 *<p>The element <span class="XMLe">Adresa_ARES</span> contains the address of the entity, which is standardized on the basis of data from UIR-ADR(i.e. improved names of the streets, completed numbers of houses, postcodes improved on the basis of UIR-ADR data;if the address of the entity is not assign unambiguously to the address in UIR-ADR, it would not be standardized).The element <span class="XMLe">Adresa_UIR</span> contains the data from the UIR-ADR register.</p>
 *
 *<p>The element <span class="XMLe">Adr_puv</span> (it is written only if the parameter <code>adr_puv=true</code> is used) contains information of address of entity as it is written in the data source (before the process of standardization is used).</p>
 *
 *<div class="poznamka">
 *<p><b>Note</b>:
 *The data sources give the address in different ways. Some give it in the text, some in address codes only, some give it structured and some unstructured.
 *The output element <span class="XMLe">Adr_puv</span> contains the address, if possible, structured, 
 * text data remains unchanged and any address codes are replaced with texts according to the dials of appropriate source.
 *The address of the element <span class="XMLe"> Adr_puv </span> enters into the process of address standardization during data processing in ARES.
 *The address standardization creates the standardized address contained in the element <span class="XMLe">Adresa_ARES</span>.
 *</div>
 *
 *      <p>Other information on an entity:
 *      <br />In addition to basic data concerning the entity, the Basic service displays further information specific for individual sources, for example, registration authorities, wording of trade authorisations, scope of business activity, CZ-NACE, statistical information.</p>
 *
 *      <p>As a part of the output you can find a list of entity's registrations in individual source registers. This information is included in the element <span class="XMLe">Priznaky_subjektu</span> together with an indication whether the given registration is valid or defunct.</p>
 *
 *<p>The letters in the element mean:
 *  <table class="TInvisible lvl2">
 *  <tr><td><code>A</code></td><td>valid registration</td></tr>
 *  <tr><td><code>Z</code></td><td>defunct registration</td></tr>
 *
 *  <tr><td><code>S</code></td><td>in position No. 6, it indicates a Group VAT Registration</td></tr>
 *  <tr><td><code>P</code></td><td>in position No. 15, it indicates suspension of the activity</td></tr>
 *  <tr><td><code>E</code>, <code>F</code></td><td>in position No. 22, it indicates that a record concerning the economic entity occurs in the Insolvency Register. Please, pay special attention to the state of the proceedings!</td></tr>
 *  <tr><td><code>N</code> (or some other character)</td><td>not found in registration</td></tr>
 *
 *  </table>
 * <div class="poznamka">
 *   <p><b>Note</b>: >: Some other &quot;service&quot; characters can occur.
 *   All of them should be considered as &quot;<code>N</code>&quot; character.</p>
 * </div>
 *
 *<p>Individual positions in the element indicate that:
 *<table class="TInvisible lvl2">
 *<tr><td><code>1</code></td><td>reserved</td></tr>
 *<tr><td><code>2</code></td><td>the entity exists in the Commercial Register</td></tr>
 *<tr><td><code>3</code></td><td>the entity exists in the Statistical Register of Economic Subjects</td></tr>
 *<tr><td><code>4</code></td><td>the entity exists in the Trade Register</td></tr>
 *<tr><td><code>5</code></td><td>the entity exists in the Register of Health Service Institutions</td></tr>
 *
 *<tr><td><code>6</code></td><td>the entity exists in the Register of VAT Payers</td></tr>
 *<tr><td><code>7</code></td><td>the entity exists in the Register of Excise Duty Payers</td></tr>
 *<tr><td><code>8</code></td><td>reserved</td></tr>
 *<tr><td><code>9</code></td><td>the entity exists in the Central Register of Bankrupts - bankruptcy</td></tr>
 *<tr><td><code>10</code></td><td>the entity exists in the Central Register of Bankrupts - compositions</td></tr>
 *<tr><td><code>11</code></td><td>the entity exists in the Central Register of State Subsidies</td></tr>
 *
 *<tr><td><code>12</code></td><td>the entity exists in the Special register of organisations in the ARIS system</td></tr>
 *<tr><td><code>13</code></td><td>the entity exists in the List of foreign exchange spots and licences</td></tr>
 *<tr><td><code>14</code></td><td>the entity exists in the Register of Church and Religious Institutions</td></tr>
 *<tr><td><code>15</code></td><td>the entity exists in the Register of Political Parties and Movements</td></tr>
 *<tr><td><code>16</code></td><td>the entity exists in the List of Insurance and Reinsurance Companies</td></tr>
 *<tr><td><code>17</code></td><td>the entity exists in the List of Responsible Actuaries</td></tr>
 *
 *<tr><td><code>18</code></td><td>the entity exists in the List of Insurance Intermediaries and Independent Loss Adjusters</td></tr>
 *<tr><td><code>19</code></td><td>reserved</td></tr>
 *<tr><td><code>20</code></td><td>the entity exists in the List of Civic Associations, Guilds and Clubs</td></tr>
 *<tr><td><code>21</code></td><td>the entity exists in the Common Agricultural Register</td></tr>
 *<tr><td><code>22</code></td><td>the entity exists in the Insolvency Register</td></tr>
 *<tr><td><code>23</code></td><td>the entity exists in the Register of Schools and School Facilities</td></tr>
 *
 *<tr><td><code>24 - 30</code></td><td>reserved</td></tr>
 *</table></p>
 *
 * Date of create: May 22, 2011
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 * @version 2011.0522
 */
public class BasicService extends EmptyService{
    
    private final Map<String, Converter> converters = new HashMap<String, Converter>();
    private Logger log = Logger.getLogger(this.getClass().getName());

    public BasicService() {
        log.debug("Creating address service!");
        String[] ver = new String[]{"1.0.3", "1.0.2"};
        converters.put("ico", new RegExpConverter(RegExpConverter.ICO_REGEPX));
        converters.put("aktivni", new TypeConverter("boolean"));
        converters.put("xml", new EnumConverter(Xml.XML));
        converters.put("jazyk", new EnumConverter(Jazyk.EN));
        converters.put("ver", new StringEnumConverter(ver));
        setConverters(converters);
        String[] obligatory = new String[]{"ico"};
        setObligatory(obligatory);
        String[] oneOf = new String[]{};
        setOneOf(oneOf);
        
        try {
            putParam("xml", "0");
            putParam("jazyk", Jazyk.EN.value());
        } catch (ParameterNotAllowedException ex) {
            log.error("Thrown unexpected exception. This never happened!" + ex);
        }
        
        setServiceUrl("http://wwwinfo.mfcr.cz/cgi-bin/ares/darv_bas.cgi");
        log.debug("Basic service created!");
    }
    
    public BasicService(VersionEnum version){
        this();
        try {
            putParam("ver", version.value());
        } catch (ParameterNotAllowedException ex) {
            log.error("Thrown unexpected exception. This never happened!" + ex);
        }
    }
}
