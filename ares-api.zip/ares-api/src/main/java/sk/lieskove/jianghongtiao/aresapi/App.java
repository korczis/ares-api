/*
 *  Copyright (C) 2011 JiangHongTiao <jjurco.sk_gmail.com>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.aresapi;

import sk.lieskove.jianghongtiao.aresapi.enums.CzNaceEnum;
import sk.lieskove.jianghongtiao.aresapi.webservice.services.BasicService;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.exceptions.NotEnoughParametersException;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.exceptions.ParameterNotAllowedException;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Date of create: May 15, 2011
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 * @version 2011.0515
 */
public class App 
{
    //TODO saving all responses to DB and queries for future analysis 
    public static void main( String[] args ) throws ParameterNotAllowedException, 
            IOException{
        CzNaceEnum.valueOf("980000");
        if(true)return;
        //EXAMPLE USAGE
//        AresFindPeopleImpl findPeopleImpl = new AresFindPeopleImpl();
////        findPeopleImpl.setAngazma(AresFindPeople.Angazma.VSECHNA);
////        findPeopleImpl.setCestina(AresFindPeople.Diakritika.CESTINA);
////        findPeopleImpl.setJazyk(AresFindPeople.Jazyk.CZ);
////        findPeopleImpl.setJmeno("Juraj Jurco");
////        findPeopleImpl.setMaxpoc(AresFindPeople.MaxPoc.MAX_200);
////        findPeopleImpl.setObec("Praha");
////        findPeopleImpl.setSetrid(AresFindPeople.Setrid.JMENO);
////        findPeopleImpl.setXml(AresFindPeople.XmlVystup.HTML_TRANSFORM_SERVER);
//        findPeopleImpl.setRc("6203010176");
//        findPeopleImpl.find();
//        findPeopleImpl.findByName("Martin Lala");
//        System.out.println("URL: " + findPeopleImpl.makeUrl());
        //EXAMPLE of AddressService
//        AddressService service = new AddressService();
//        service.putParam("adresa_textem", "Praha, Podvinný mlýn 2178");
//        try {
//            System.out.println(service.getAnswer().getAbsoluteFile());
//        } catch (NotEnoughParametersException ex) {
//            Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
//        }
        //EXAMPLE of BasicService
        BasicService basicService = new BasicService();
        basicService.putParam("ico", "25686976");
        try {
            System.out.println(basicService.getAnswer().getFile().getAbsolutePath());
        } catch (NotEnoughParametersException ex) {
            Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        System.in.read();
    }
}
