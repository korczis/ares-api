/*
 * Copyright (C) 2011 JiangHongTiao
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.aresapi.webservice.services;

import org.apache.log4j.Logger;
import sk.lieskove.jianghongtiao.aresapi.enums.Jazyk;
import sk.lieskove.jianghongtiao.aresapi.enums.VersionEnum;
import sk.lieskove.jianghongtiao.aresapi.enums.Xml;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.converter.Converter;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.converter.EnumConverter;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.converter.RegExpConverter;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.converter.StringEnumConverter;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.exceptions.ParameterNotAllowedException;

import java.util.HashMap;
import java.util.Map;

/**
 *  <h3>Input</h3>
 * obligatory parameter:
 * <br /><code>ico</code>
 *      <p>parameters:
 *      <table class="TInvisible">
 *       <tr><td class="PAlignRight"><code>ico</code></td><td> - Reg.No. is an identification number under which the entity is registered
 *       in the Commercial Register.
 *       The parameter is numerical, its maximum length is 8 digits. There is no need to enter the leading zeroes.
 *	</td></tr>
 *       <tr><td class="PAlignRight"><code>xml</code></td><td>
 *          <code>=0</code> - xml (default value)<br />
 *
 *          <code>=1</code> - html, transformation performed in browser on user's PC<br />
 *          <code>=2</code> - html, transformation from xml performed on server</td></tr>
 *       <tr><td class="PAlignRight"><code>jazyk</code></td><td> - defines the text of html pages<br />
 *          <code>=cz</code> - html in Czech (default value)<br />
 *
 *    		  <code>=en</code> - html in English</td></tr>
 *       <tr><td class="PAlignRight"><code>ver</code></td><td> - defines the xml output version (For details see <a href="ares_xml_get.html.en">Notes and recommendations</a>)<br />
 *          <code>=1.0.4</code> - economy-sized xml with element names in abbreviations (default value)<br />
 *
 *       </tr>
 *       </table>
 *
 *      <h3>Output</h3><br />
 *
 *      <p>List of bankrupts if there is any with such ICO</p>
 *
 * Date of create: Oct 10, 2011
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 * @version 2011.1010
 */
public class RegisterOfBankruptsService extends EmptyService{
    
    private final Map<String, Converter> converters = new HashMap<String, Converter>();
    private Logger log = Logger.getLogger(this.getClass().getName());

    public RegisterOfBankruptsService() {
        log.debug("Creating "+this.getClass().getSimpleName()+" service!");
        String[] ver = new String[]{"1.0.4"};
        converters.put("ico", new RegExpConverter(RegExpConverter.ICO_REGEPX));
        converters.put("xml", new EnumConverter(Xml.XML));
        converters.put("jazyk", new EnumConverter(Jazyk.EN));
        converters.put("ver", new StringEnumConverter(ver));
        setConverters(converters);
        setObligatory(new String[]{"ico"});
        setOneOf(new String[]{});
        
        try {
            putParam("xml", "0");
            putParam("jazyk", Jazyk.EN.value());
        } catch (ParameterNotAllowedException ex) {
            log.error("Thrown unexpected exception. This never happened!" + ex);
        }
        
        setServiceUrl("http://wwwinfo.mfcr.cz/cgi-bin/ares/darv_ceu.cgi");
        log.debug(this.getClass().getSimpleName()+" service created!");
    }
    
    public RegisterOfBankruptsService(VersionEnum version){
        this();
        try {
            putParam("ver", version.value());
        } catch (ParameterNotAllowedException ex) {
            log.error("Thrown unexpected exception. This never happened!" + ex);
        }
    }
    
}
