/*
 * Copyright (C) 2011 JiangHongTiao
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.aresapi.webservice.services;

import org.apache.log4j.Logger;
import sk.lieskove.jianghongtiao.aresapi.enums.*;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.converter.*;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.exceptions.ParameterNotAllowedException;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 *     <div class="lvl2"><h2 id="k1">1. Data on Economic Entities</h2>
 *    <p>The application enables you to search for economic entities in ARES on 
 *    the basis of various search criteria. Consequently, you can display detailed information 
 *    contained in the source registers. As a part of each output you can find a direct reference to 
 *    a WWW application of the institution operating the particular source register 
 *    (the Commercial Register of the Ministry of Justice, the Register of Economic Entities 
 *    of the Czech Statistical Office, the Trade Register of the Ministry of Industry 
 *    and Trade, ...). Such access to all information on the entity, in all information systems 
 *    of the state administration where the data is maintained, enables you to compare the data and obtain 
 *    a total overview.</p> 
 *    <p>In some cases, the information kept in individual source registers 
 *    is inaccurate or obsolete. Sometimes, information concerning one entity differs 
 *    from register to register. In exceptional cases, the search for an existing entity may fail, 
 *    especially if a duplicate Reg.No. was issued by mistake, or if a properly assigned Reg.No. 
 *    was not entered into the information system at all. This situation is caused by discrepancies 
 *    in the development of information systems operated by the source registers. Especially, this is the question 
 *    of historical records coming from the period of economic transformation in the early 1990s. 
 *    To correct the inaccurate data, the entity concerned can call upon 
 *    <a href="ares_rm.html.en">registration 
 *    authority</a> to amend them. The ARES database will be updated 
 *    automatically just after the update of the corresponding authority's source database. 
 *    It ought to be an interest of each entity to ask for data correction 
 *    in case of data inaccuracy.</p></div> 
 *     <div class="line10"></div>
 *    <div class="lvl2"><h2 id="k2">2. Completing the Entry Form</h2>
 *    <p>No compulsory search criteria are given for this application. However, it is recommended 
 *    that at least one of the parameters <b>Business name</b>, <b>Reg. No.</b> or some parameters concerning address should be used. 
 *    Since the Reg. No. is a unique identifier of an economic entity, it becomes 
 *    the most convenient search criterion. If you search by address, it is necessary 
 *    to use <b>Town</b>. To move through various entry fields, use TAB key 
 *    or place the pointer in the field desired and click with the left mouse button. To clear the entry form, 
 *    use the <b>New specifications</b> button.</p> 
 *    
 *    <p>The following rules apply to the fields in the entry form:</p>
 *    <div class="lvl3"><h3>Reg.No.</h3>
 *    <p>Use this field to enter the identification number (Reg. No.) of the entity you are searching for. 
 *    This number was assigned to the entity by the Commercial Register, the Trades Licensing Office or by the Czech Statistical Office. 
 *    The search by this criterion is the fastest one. It is unacceptable 
 *    to combine this criterion with other criteria. The maximum length for this field is 8 characters. Solely digits are permitted. 
 *    There is no need to enter the leading zeroes in the Reg. No..</p></div> 
 *    
 *    <div class="lvl3"><h3>Business name</h3>
 *    <p>Use this field to enter the name of the searched entity (business name, 
 *    name of entrepreneur). The maximum length for this field is 254 characters. Upper-case letters 
 *    and lower-case letters may be used interchangeably. The Czech set of characters can be enabled 
 *    or disabled during the search. (To switch over, use the additional parameter 
 *    Diacritics); if you use ASCII, the search runs regardless of diacritical 
 *    marks.</p>
 *    <p>It is not necessary to enter the business name in full. It is sufficient to enter several words 
 *    you assume the name contains, regardless of their order. Letters and digits are significant characters 
 *    for searching, any other character is regarded as a space. If several one-letter words are entered in sequence, 
 *    they are regarded as one interspaced word 
 *    and the spaces between them are automatically deleted. (Therefore, the same result comes from 
 *    searching for the text of s r. o., s r.o., sro). You can also use 
 *    wildcard character * (for a group of characters) and ? (for a single character). In such a case, please adhere to the rule 
 *    that the word must contain either at least 3 consecutive significant characters like letters 
 *    and digits, or 4 significant characters in total (it is acceptable to enter vod*, *ody, vo*dy, 
 *    vo*dy*, dol?, unacceptable entry is vo?y, vo*y). Unsuitable location of the wildcard characters 
 *    (for example, at the beginning of a text) can slow the search significantly.</p>
 *    <p>If the Business name contains some of wildcard characters (*, ?), these characters shall not be used when searching by Business name. We recommend you to omit them.</p></div>
 *
 *    <div class="lvl3"><h3>Town</h3>
 *    <p>Use this field to enter the town in which the registered office 
 *    or the place of business of the searched entity is located. It is important to enter an exact town name including the Czech diacritics (whether upper-case or 
 *    lower-case letters), or a town code. The maximum length for this field is 48 characters. 
 *    To fill in this field properly, take advantage of a list of towns which is available by clicking on <b>Town</b>. 
 *    According to a capability of your browser, the town code is either automatically transferred 
 *    to the entry form just after clicking on <b>Town name</b>, or you must copy the <b>Town code</b> manually 
 *    into the form.</p>
 *    <p>If you do not enter the whole town name into this field, but only some words from the name, 
 *    the entity is searched in all towns the names of which contain the entered words 
 *    (for example, if you enter Boleslav, the entity is searched in the towns named Mladá Boleslav as well as 
 *    Brandýs nad Labem-Stará Boleslav). For towns consisting of town districts, you can enter a town name 
 *    or a name of the town district (Praha, Brno, Ostrava, Plzen, Pardubice, 
 *    Liberec, Usti nad Labem, Havirov).</p></div>
 *    
 *    <div class="lvl3"><h3>Street</h3>
 *
 *    <p>Use this field to enter the street in which the seat of the required entity is located. The maximum length for this field is 45 
 *    characters. Upper-case letters and lower-case letters may be used interchangeably. Diacritics 
 *    are not important for this parameter. The 9 first characters in the street name are of great importance. 
 *    The wildcard characters * and ? do not work here. Together with this parameter, it is necessary 
 *    to use <b>Town</b>.</p></div>
 *    
 *    <div class="lvl3"><h3>House number</h3>
 *    <p>The two 5-character fields of this parameter let you insert a land-registry number 
 *    and a sequence number of a house. It is possible to enter just one number or both of them 
 *    regardless of their order.</p>
 *    <p>It is necessary to use this parameter together with <b>Town</b> or 
 *    <b>Business name</b>.</p></div>
 *
 *    <div class="lvl3"><h3>Tax Office</h3>
 *    <p>Use this field to enter the code of the tax office desired. Solely digits are 
 *    permitted. The maximum length for this field is 3 characters. It is recommended that this field be used solely 
 *    in combination with further search criteria. If not, 
 *    the search results in too many matching entities.</p> 
 *    <p>It is useful to take advantage of a list of tax offices (by clicking on <b>Tax Office</b>). 
 *    According to a capability of your browser, the tax office code is either automatically transferred 
 *    to the entry form by clicking on the tax office name or you must copy the code 
 *    manually.</p></div>
 *    
 *    <div class="lvl3"><h3>Legal form</h3>
 *    <p>You can simply enter the required legal form or make use of a list attached. 
 *    The maximum number of the digits entered is 3. It is recommended that this criterion be used in combination with 
 *    further search criteria, at least with <b>Town</b>.</p></div>
 *
 *    <div class="lvl3"><h3>CZ-NACE</h3>
 *    <p>It is possible to enter either one CZ-NACE code or a range of CZ-NACE codes into two fields of the entry form. 
 *    The CZ-NACE is a 6-digit code. You can either insert the code directly into the field, or take advantage of the 
 *    List of CZ-NACE - groups of activities by clicking on <b>CZ-NACE</b>. In the said list, 
 *    two ways of the code selection are possible. First, click on a particular 
 *    code here and the code will be automatically transferred into the form. Second, click on the name of your CZ-NACE desired in the section <b>Name 
 *    of the economic activity</b> and you will be given another list of CZ-NACE sub-group from which 
 *    you can choose one or two codes for an interval.</p> 
 *    <p>The <b>CZ-NACE</b> as a search criterion can slow down the search significantly. It is recommended that a combination with another search criterion be used, 
 *    for example, with <b>Town</b>. The CZ-NACE classification is maintained by the Czech Statistical Office. For the present, the CZ-NACE element 
 *    is displayed only in the data from the statistical register RES. 
 *    </p></div></div> 
 *    <div class="lvl2"><h2 id="k3">3. Additional Options</h2>
 *    
 *    <div class="lvl3"><h3>Filter</h3>
 *    <p>Use this option to specify the list of displayed entities more precisely, 
 *    in order to reduce the number of entities matching the search criteria. The following options are available:
 *    <ul>
 *      <li><b>all entities</b> (default value) - you will receive all entities 
 *          matching the search criteria</li>
 *      <li><b>active</b> - from the entities matching the search criteria, you will only receive that 
 *          which are indicated as active in at least one of the 
 *          basic source registers (CR, RES, TR, RCRS, ISIILA, AGC)</li>
 *
 *      <li><b>defunct</b> - from the entities matching the search criteria, you will only receive that 
 *          which are indicated as defunct in all basic 
 *          source registers.</b>
 *    </ul></p></div>
 *    
 *    <div class="lvl3"><h3>Diacritics</h3>
 *    <p>This option takes effect only together with <b>Business name</b> and defines whether 
 *    the name will be searched inclusive of diacritics (ceska option - default value) 
 *    or without diacritics (<b>ASCII</b> option).</p></div> 
 *     
 *    <div class="lvl3"><h3>View</h3>
 *
 *    <p>By this option the maximum number of displayed entities is limited. If the number 
 *    of entities matching the search criteria exceeds the limit, no entity is displayed 
 *    and an error message appears. For successful result, it is necessary 
 *    to either specify the search criteria or increase the limit value. Permitted values 
 *    for this parameter are 200, 500, 1000. However, if you choose more than 200 records, 
 *    the data display can slow down. The default value is 200.</p></div>
 *    
 *    <div class="lvl3"><h3>Sorting</h3>
 *    <p>Use this option to define an order of entities displayed. 
 *   The following options are available:</p> 
 *     <ul>
 *      <li>unsorted (default value)</li>
 *      <li>sorting by <b>Reg. No.</b></li>
 *
 *      <li>sorting by <b>Town</b></li> 
 *      <li>sorting by <b>Business name</b></li>
 *     </ul> 
 *    </div>
 *    
 *    <div class="lvl3"><h3>Output</h3>
 *    <p>A file containing information on entities in ARES is generated in XML format. If necessary, 
 *    the said file is transformed into HTML format. 
 *    The transformation can be performed either on a server or in a user's browser.</p>
 *    <p>The following options for the output format are available:
 *      <ul>
 *
 *        <li><b>HTML</b> - the transformation into HTML format is performed in the user's browser</li> 
 *        <li><b>HTML server</b> - the transformation into HTML format is performed on the server </li>
 *        <li><b>XML</b> - remains in XML format</li>
 *      </ul>
 *    The transformation in the browser is server friendly. According to the existing rule, 
 *    you should not switch this option between 
 *    the search for a person and the follow-on call for a detailed output 
 *    (CR, RES, TR,...). Each time you switch this option, use the 
 *    <b>Search</b> button prior to the next step.</p>
 *
 *    
 *    <div class="poznamka">
 *    <p><b>Note</b>: Some browsers might not transform the data correctly. In such a case, 
 *    please use the transformation on the server.</p></div></div>
 *    
 *    <div class="lvl3"><h3>Search</h3>
 *    <p>This button starts the process of searching by the search criteria entered. 
 *    The result is displayed in <b>ARES - List of selected economic entities</b>.</p></div>
 *    
 *    <div class="lvl3"><h3>Persons</h3>
 *
 *    <p>Use this option to switch directly to searching for a person (public 
 *    by law). This is the question of those natural persons, who are secretaries, members of statutory bodies, or 
 *    who hold other positions (roles) in economic entities kept in the Commercial Register 
 *    or in the Register of Insurance Intermediaries and Loss Adjusters, and whose particulars 
 *    are public by law.</p></div></div>
 *    <div class="lvl2"><h2 id="k4">4. Getting Information on Entities</h2>
 *    <p>When you press <b>Search</b>, a list of all economic entities matching the search criteria 
 *    appears in the bottom frame of the window. Response time depends on the number of 
 *    such entities.</p>
 *    <p>The following particulars are displayed in the list of selected entities:</p> 
 *    <ul>
 *      <li>Reg.No. of the entity</li>
 *      <li>Business name</li>
 *      <li>Registered office / Place of business (town, street + number, or residential area)</li> 
 *      <li>the list of abbreviations of respective source registers. The abbreviations serve as references 
 *    to detailed information on the entity as registered with particular sources (a list of available sources is given in 
 *    <a href="ares_popis.html.en">description</a> of the ARES IS)</li>
 *
 *      <li>the list of graphic icons. The icons enable you to access to detailed information on the entity (for example, 
 *    Correspondence between registers); the meaning of individual icons is specified by tool tips)</li>
 *    </ul>
 *    <div class="poznamka">
 *    <p><b>Note:</b></p>
 *    <ul>
 *      <li>if some of the source registers (CR, RES, TR, ...) is not mentioned with the entity, 
 *    it means that the entity is not registered with the register concerned</li>
 *      <li>the rows that are not highlighted represent active entities</li> 
 *      <li>if the reference to the source register is highlighted in grey, it indicates 
 *    that the entity is defunct in this source</li>
 *
 *      <li>if the whole row is highlighted in grey, the entity is indicated as defunct 
 *    in all main source registers</li>
 *    </ul> 
 *    </div>
 *    <h3>Outputs of particulars of an entity from source registers</h3>
 *    
 *    <p>For each of the selected entities you can display detailed information. 
 *    By clicking on the abbreviation of particular source register in the <b>Reference</b> column you open a window 
 *    with particulars of the entity from the register concerned. You are given either 
 *    a data output generated in the ARES application (namely for CR, RES, TR, RCRS...), 
 *    or directly the WWW sites on the server of the institution operating 
 *    the relevant source register (namely for ED, VAT, BR, ...).</p>
 *    
 *    <p>If an economic entity (Reg.No.) is registered with the register more than once, 
 *    all these registrations will be displayed in one data output. 
 *    At the beginning of the said output you can find an overview of the registrations with 
 *    references to particular outputs. The difference between valid and cancelled registrations 
 *    is highlighted.</p>
 *    <p>More than one data output for one entity can occur in the following registers:
 *      <ul>
 *        <li><b>CR</b> - list of file numbers</li>
 *        <li><b>TR</b> - list of registration offices</li>
 *        <li><b>ISPOZ</b> - list of registration numbers</li>
 *
 *        <li><b>HSI</b> - list of health service institutions</li>
 *      </ul>
 *    </p>
 *    <p>The outputs generated in ARES can include further references or buttons such as:</p>
 *    <ul>
 *      <li>references to external sites of WWW applications of that institutions which 
 *      operate particular source registers provided that such applications exist 
 *      and are available to the public, for example:
 *        <ul>
 *
 *        <li>for CR, the reference to <a href="http://www.justice.cz" target="_blank">the Ministry of Justice</a></li>
 *        <li>for TR, the reference to <a href="http://www.rzp.cz" target="_blank">the Ministry of Industry and Trade</a></li>
 *        <li>for RES, the reference to <a href="http://dw.czso.cz" target="_blank">the Czech Statistical Office</a></li>
 *        <li>for RCRS, the reference to <a href="http://www3.mkcr.cz/cns_internet/CNS/Podminky.aspx" target="_blank">the Ministry of Culture</a></li>
 *        <li>for ISIILA, the reference to <a href="http://ispoz.cnb.cz" target="_blank">the Czech National Bank</a></li>
 *
 *        <li>for AGC, the reference to the List of Civic Associations, Guilds and Clubs at <a href="http://aplikace.mvcr.cz/rady/sdruzeni/index.html" target="_blank">at web sites of the Ministry of the Interior</a></li>
 *        <li>for HSI, the reference to the Register of Health Service Institutions at web sites of 
 *	<a href="http://www.uzis.cz/uzis/rzz/rzz.htm" target="_blank">the Institute of Health Information and Statistics of the Czech Republic</a/></li>
 *        <li>for RAE, the reference to the Register of Agricultural Entrepreneurs at Farmer’s Portal of 
 *	<a href="https://farmar.mze.cz/szr/SZR3PFV001.ASP" target="_blank">the Ministry of Agriculture</a></li>
 *        <li>for PPM, the reference to the Register of Political Parties and Movements at web sites of 
 *	<a href="http://aplikace.mvcr.cz/seznam-politickych-stran/" target="_blank">at web sites of the Ministry of the Interior</a></li>
 *        </ul>
 *
 *      </li>
 *      <li>the full output (history) (only for an output from CR): particulars from 
 *          the Commercial Register are displayed including historical data, which has been kept in ARES since 1998</li>
 *      <li>references to different kind of outputs from the Trade Register: basic information on the entity 
 *          from TR (brief), data output containing valid trades (trades), or data output containing 
 *          permanent establishments (permanent establishments)</li>
 *      <li>the standardized address for the items containing an address (a registered office, 
 *          place of business, residence, permanent establishment...)</li>
 *      <li>the output of the standardized address contains a reference to a map (implemented 
 *          through the reference of mapy.cz)</li>
 *      <li>PRINT button - the output format is ready for printing</li>
 *    </ul>
 *    </div>
 *    <div class="line10"></div>
 *     
 *    <div class="lvl2"><h2 id="k5">5. Electronically signed documents (TR and CR)</h2>
 *    <ul>
 *      <li><b>Electronically signed documents from the Trade Register</b> are available
 *      only through the server of the Ministry of Industry and Trade,
 *      at <a href="http://www.rzp.cz" target="_blank">www.rzp.cz</a>. Here you can choose 
 *      <b>vypis bez historie</b>, i.e., an output without history, or <b>vypis s historii</b>, i.e., an output with history.
 *      At the bottom of these outputs you can find the references to the electronically signed document in PDF format 
 *      or to the documents in XML format.</li></p>
 *
 *      <li><cz><b>Electronically signed documents from the Commercial Register</b> are not available to the public. 
 *      Applicants must apply to a relevant registration court, or to the office authorized by the Ministry of Justice. 
 *      These are notaries who are members of the Notary Chamber, furthermore the Economic Chamber, the Czech Post 
 *      and Municipal Authorities with an extended sphere of authority. Information is available 
 *      against a fee.</li>
 *    </ul>
 *    </div>
 *    <div class="lvl2"><h2 id="k6">6. Recommendation concerning the display of particulars of the entity</h2>
 *    
 *    <p>The list of selected entities as well as the output of detailed information 
 *    on economic entities are generated as a XML file and after that the said file is transformed into a required 
 *    format (in this case it is HTML). 
 *    When being transformed on the server side, no changes can be seen from the user point of view and 
 *    the required data from ARES is sent in HTML format onto the user's computer. 
 *    When being transformed on the user side, the XML (text-based) file is sent onto the user's computer and 
 *    then it is transformed into the required HTML format. 
 *    The transformation proceeds under control of a browser and no executable programs are downloaded 
 *    onto the user's computer. Only when processing the first transformation  request, 
 *    the templates required for the transformation are downloaded from the ARES server onto 
 *    the user's computer (only small text-based files).</p>
 *    <p>To ensure proper dealing with temporary files, the browser setting must be able 
 *    to find out the existence of newer versions (preferably on every visit to the web site 
 *    concerned). If the transformation on the user side is not successful, it is necessary to choose 
 *    the transformation on the server side. With respect to a great number of queries posed against ARES as well as 
 *    to the server load, we recommend using the transformation on the user side 
 *    (provided that the configuration of the user's computer enables to do it).</p>
 *    
 *    <p>If the HTML checkbox is activated in the ARES entry form, the transformation is performed on the user's side. 
 *    If the HTML server checkbox is activated, the transformation is performed on the server side. 
 *    It is necessary to define this option prior to the search for an economic entity. 
 *    Each time you change this option, use the  
 *    <b>Search</b> button prior to the next step.</p>
 *    
 *    <p>If no particulars from the source register appear after clicking on a text in the <b>Reference</b> column, 
 *    please try one of the following 
 *    options:</p>
 *
 *    <ul>
 *      <li>do not close the window containing an output of particulars - after clicking on 
 *    another reference (source register) the window will be automatically rewritten</li>
 *      <li><b>prior to the search</b> for an economic entity, change the <b>Output</b> option
 *      to &quot;HTML server&quot;, click with the right mouse button on the reference and select 
 *      Open in New Window</li> 
 *    </ul>
 *    <p>The defects can be caused by some versions of browsers that are not able to 
 *    display the required data properly in HTML format. At present, these defects no more occur in Internet Explorer 7 
 *    and Mozilla Firefox 2.x. Should you find the above-mentioned instructions unhelpful, please send your 
 *    query together with your contact address to 
 *    <a href="mailto:ares@mfcr.cz">ares@mfcr.cz</a>. We are at your disposal to resolve 
 *    the problem with you and enable you to use the fully functional ARES system.</p>
 *    </div>
 * 
 *       Example URL: <code><a href="http://wwwinfo.mfcr.cz/cgi-bin/ares/ares_es.cgi?obch_jm=ASSECO+a.s.&xml=0">http://wwwinfo.mfcr.cz/cgi-bin/ares/ares_es.cgi?obch_jm=ASSECO+a.s.&xml=0</a></code>
 *
 *      <div class="poznamka">
 *      <b>Note:</b> It is not necessary to specify the unfilled parameters.
 *      The parameter values shall be entered to the extent permitted by the Entry Form, see
 *      <a href="http://wwwinfo.mfcr.cz/ares/ares_es_help.html.en#k2">Help</a>.
 *      Especially, when using the computerized XML inquiries, please be particular about entering the valid and meaningful parameters.
 *      Failing this, the user's access to ARES IS could be made impossible. 
 *      </div>
 *
 *      <h3>Parameters:</h3>
 *      <p>
 *      <table class="TInvisible">
 *
 *       <tr><td class="PAlignRight"><code>obch_jm</code></td><td>Business name. We do not recommend you to use the following characters: * ? &amp; %</td></tr>
 *       <tr><td class="PAlignRight"><code>ico</code></td><td>Reg.No.
 *	(Reg.No. specification makes other search criteria redundant.)</td></tr>
 *       <tr><td class="PAlignRight"><code>obec</code></td><td>Town name</td></tr>
 *       <tr><td class="PAlignRight"><code>k_fu</code></td><td>Tax Office code</td></tr>
 *
 *       <tr><td class="PAlignRight"><code>maxpoc</code></td><td>Maximum number of entities displayed. Permitted values: 200, 500, 1000.</td></tr>
 *       <tr><td class="PAlignRight"><code>ulice</code></td><td>Street name in address
 *        (The Street parameter requires the Town parameter to be entered.)</td></tr>
 *       <tr><td class="PAlignRight"><code>cis_or</code></td><td>Sequence number in address</td></tr>
 *       <tr><td class="PAlignRight"><code>cis_po</code></td><td>Land-registry number in address
 *	(Together with House No. enter at least one of the parameters: Town, Business name.)</td></tr>
 *       <tr><td class="PAlignRight"><code>setrid</code></td><td>An order of the displayed entities can be as follows:<br>
 *
 *    		  <code>=ZADNE  </code>- unsorted<br>
 *    		  <code>=ICO    </code>- sorted by Reg.No.<br>
 *    		  <code>=OBEC   </code>- sorted by Town<br>
 *    		  <code>=OBCHJM </code>- sorted by Business name</td></tr>
 *       <tr><td class="PAlignRight"><code>pr_for</code></td><td>Code of the legal form</td></tr>
 *
 *       <tr><td class="PAlignRight"><code>nace</code></td><td>CZ-NACE code, if also
 *                  <code>nace_h</code> is filled in, the lower limit of CZ-NACE interval is in <code>nace</code> </td></tr>
 *       <tr><td class="PAlignRight"><code>nace_h</code></td><td>upper limit of CZ-NACE interval</td></tr>
 *       <tr><td class="PAlignRight"><code>xml</code></td><td>
 *          <code>=0</code> - output in xml<br>
 *
 *          <code>=1</code> - output in html, transformation performed in browser on user's PC<br>
 *          <code>=2</code> - output in html, transformation from xml performed on server</td></tr>
 *       <tr><td class="PAlignRight"><code>filtr</code></td><td>filtering the output of entities already selected<br>
 *    		  <code>=0</code> - all selected entities displayed<br>
 *
 *    		  <code>=1</code> - only active entities displayed<br>
 *    		  <code>=2</code> - only defunct entities displayed</td></tr>
 *       <tr><td class="PAlignRight"><code>jazyk</code></td><td>
 *          <code>=cz</code> - html in Czech<br>
 *
 *    		  <code>=en</code> - html in English</td></tr>
 *       <tr><td class="PAlignRight"><code>cestina</code></td><td><code>=cestina</code> - Business name is entered with diacritical marks<br>
 *          (in the entry form: Diacritics: ceska), without this parameter 
 *          (i.e., Diacritics: ASCII) no diacritical marks are assumed to be in Business name</td></tr>    		  
 *      </table>
 *      <div class="poznamka"><b>Note:</b> Output filtering starts AFTER 
 *      THE SELECTION of entities matching the search criteria! If the number of entities selected before filtering 
 *      exceeds the <code>maxpoc</code>, an error message appears, even in case that the number 
 *      of entities after filtering complies with <code>maxpoc</code>!</div>
 *
 * 
 * Date of create: May 22, 2011
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 * @version 2011.0522
 */
public class EconomicEntitiesService extends EmptyService{
    
    private final Map<String, Converter> converters = new HashMap<String, Converter>();
    private Logger log = Logger.getLogger(this.getClass().getName());

    public EconomicEntitiesService() {
        log.debug("Creating "+this.getClass().getSimpleName()+" service!");
     
        String[] ver = new String[]{"1.0.0", "1.0.3"};
        converters.put("ver", new StringEnumConverter(ver));
        converters.put("ico", new RegExpConverter(RegExpConverter.ICO_REGEPX));
        converters.put("obch_jm", new LengthRangeConverter(null, 255));
        converters.put("obec", new LengthRangeConverter(2, 48));
        converters.put("k_fu", new IntRangeIncludeConverter(0, 558));
        converters.put("ulice", new LengthRangeConverter(1, 48));
        converters.put("cis_or", new LengthRangeConverter(null, 4));
        converters.put("cis_po", new IntRangeIncludeConverter(1, 9999));
        converters.put("pr_for", new IntRangeIncludeConverter(1, 999));
              
        /**
         * TO DO: make converter for this type:okec/okec_h. Check documentation!
         */
        converters.put("okec", new EnumConverter(CzNaceEnum.CZNACE_000000));
        converters.put("okec_h", new EnumConverter(CzNaceEnum.CZNACE_000000));
                  
        converters.put("maxpoc", new EnumConverter(MaxPocEnum.MAX_200));
        converters.put("setrid", new EnumConverter(EsSetridEnum.ICO));
        converters.put("filtr", new EnumConverter(ESFilterEnum.ALL));
        converters.put("cestina", new StringEnumConverter(new String[]{"cestina"}));
        converters.put("xml", new EnumConverter(Xml.XML));
        converters.put("jazyk", new EnumConverter(Jazyk.EN));
                
        setConverters(converters);
        setObligatory(new String[]{});
        setOneOf(new String[]{"ico"});
        
        try {
            putParam("xml", "0");
            putParam("jazyk", Jazyk.EN.value());
        } catch (ParameterNotAllowedException ex) {
            log.error("Thrown unexpected exception. This never happened!" + ex);
        }
        
        setServiceUrl("http://wwwinfo.mfcr.cz/cgi-bin/ares/ares_es.cgi");
        log.debug(this.getClass().getSimpleName()+" service created!");
    }
    
    public EconomicEntitiesService(VersionEnum version){
        this();
        try {
            putParam("ver", version.value());
        } catch (ParameterNotAllowedException ex) {
            log.error("Thrown unexpected exception. This never happened!" + ex);
        }
    }
}
