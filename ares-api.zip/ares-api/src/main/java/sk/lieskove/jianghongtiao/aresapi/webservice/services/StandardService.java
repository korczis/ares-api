/*
 * Copyright (C) 2011 JiangHongTiao
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.aresapi.webservice.services;

import org.apache.log4j.Logger;
import sk.lieskove.jianghongtiao.aresapi.enums.AresVyberTypEnum;
import sk.lieskove.jianghongtiao.aresapi.enums.Jazyk;
import sk.lieskove.jianghongtiao.aresapi.enums.Xml;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.converter.*;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.exceptions.ParameterNotAllowedException;

import java.util.HashMap;
import java.util.Map;

/**
 *   <h3>Input</h3>
 *
 *  key parameters (it is required to enter at least one of these two parameters):
 *  <p><code>ico</code> or <code>obchodni_firma</code></p>
 * <p>parameters:
 *
 * <table class="TInvisible">
 * <tr><td class="PAlignRight"><code>ico</code></td><td> - Reg.No..
 * This number was assigned to the entity either by the Commercial Register, the Trades Licensing Office or by the Czech Statistical Office. The parameteris numerical, its maximum length is 8 digits. There is no need to enter the leading zeroes.
 * </td></tr>
 *
 * <tr><td class="PAlignRight"><code>obchodni_firma</code></td><td> - Business name. We do not recommend you to use the following characters: &amp; %.
 * To use the wildcard characters * ? , please read Help 
 * <a href="http://wwwinfo.mfcr.cz/ares/ares_es_help.html.en#k2">in the paragraph of Business name</a>.</td></tr>
 *
 * <tr><td class="PAlignRight"><code>nazev_obce</code></td><td> - takes effect only together with entered <code>obchodni_firma</code></td></tr>
 * <tr><td class="PAlignRight"><code>kod_pf</code></td><td> - the selection is executed only for a concrete code of the legal form</td></tr>
 *
 * <tr><td class="PAlignRight"><code>typ_registru</code></td><td> - when <code>obchodni_firma</code> is entered, the selection is executed only for a concrete code of the register in ARES. See the paragraph Individual positions in the element <span class="XMLe">Priznaky_subjektu</span> below.</td></tr>
 *
 * <tr><td class="PAlignRight"><code>xml</code></td><td>
 * <code>=0</code> - xml (default value)<br>
 *
 * <code>=1</code> - html, transformation performed in browser on user's PC<br>
 * <code>=2</code> - html, transformation from xml performed on server</td></tr>
 * <tr><td class="PAlignRight"><code>jazyk</code></td><td> - defines the text of html pages<br />
 * <code>=cz</code> - html in Czech (default value)<br>
 *
 * <code>=en</code> - html in English</td></tr>
 * <tr><td class="PAlignRight"><code>max_pocet</code></td><td>
 * <code>=10</code> <a name="max">-</a> a number from 1 to 200, (default value = 10)<br />
 * - The parameter is helpful especially when using <code>obchodni_firma</code>.<br />
 *
 * - specifies the maximum number of displayed entities; if the number of matching entities has exceeded the maximum value, no entity is displayed and the element <span class="XMLe">Pocet_zaznamu</span> equals -1<br />
 * - The program facilitates quick verification of basic information on an economic entity. The releasevalue -1 can be regarded as the fact that an incorrect query was entered. In case of multiple incorrect queries, the access from the IP address concerned is automatically made impossible.
 * When using the computerized XML inquiries, please be particular about entering valid and meaningful parameters. Failing this, the user's access to the ARES Information System could be made impossible.
 * </td></tr>
 * <tr><td class="PAlignRight"><code>aktivni</code></td><td> - defines the entity's ouput according to its activity<br />
 * <code>=true</code> - output available only for an active entity (default value)<br />
 *
 * <code>=false</code> - output available even for a defunct entity (deregistration)</td>
 * </tr>
 *
 *<tr><td class="PAlignRight">
 *<code>adr_puv</code></td><td> - 
 *extends data output by an element <span class="XMLe">Adr_puv</span> containing the original address from the data source without the process of address standardization.
 *(For details of the output address elements see <b>Output</b>.)<br />
 *
 *<code>=true</code> - data output including the element <span class="XMLe">Adr_puv</span><br />
 *<code>=false</code> - data output without the element <span class="XMLe">Adr_puv</span> (default value)
 *</td></tr>
 *
 * <tr><td class="PAlignRight"><code>typ_vyhledani</code></td><td> - specifies the selection priority when more key parameters are entered<br />
 *
 * <code>=free</code> - the search is executed by <code>ico</code>; if not found, the search is executed by <code>obchodni_firma</code> (default value)<br>
 * <code>=ico</code> - the search is executed by <code>ico</code><br />
 * <code>=of</code> - the search is executed by <code>obchodni_firma</code> (no search is executed by <code>ico</code> even if entered). </td></tr>
 *
 *
 * <tr><td class="PAlignRight"><code>diakritika</code></td><td> - specifies the method of entering the words in <code>obchodni_firma</code><br />
 * <code>=true</code> - Business name is entered with diacritical marks (default value)<br />
 * <code>=false</code> - Business name is entered without diacritical marks</td></tr>
 *
 * <tr><td class="PAlignRight"><code>czk</code></td>
 * <td> - specifies the coding of the Czech characters entered in <code>obchodni_firma</code> and <code>nazev_obce</code><br />
 * <code>=iso</code> - ISO 8859-2 (Latin 2) Character Set, which is used in Central and Eastern Europe (optional parameter, default value)<br />
 *
 * <code>=utf</code> - Unicode, UTF-8 coding</td></tr>
 * <tr><td>&nbsp;</td><td>Note to <code>utf</code>:
 * <br />The ARES database contains the words with the Czech letters:
 * <br />
 *&aacute; <!--a-->
 *&Aacute; <!--A-->
 *&#x10d; <!--c-->
 *
 *&#x10c; <!--C-->
 *&#x10f; <!--d-->
 *&#x10e; <!--D-->
 *&#x11b; <!--e-->
 *&#x11a; <!--E-->
 *&iacute; <!--i-->
 *&Iacute; <!--I-->
 *&#x148; <!--n-->
 *&#x147; <!--N-->
 *
 *&oacute; <!--o-->
 *&Oacute; <!--O-->
 *&#x159; <!--r-->
 *&#x158; <!--R-->
 *&scaron; <!--s-->
 *&Scaron; <!--S-->
 *&#x164; <!--T-->
 *&#x165; <!--t-->
 *&uacute; <!--u-->
 *
 *&Uacute; <!--U-->
 *&#x16f; <!--u-->
 *&#x16e; <!--U-->
 *&yacute; <!--y-->
 *&Yacute; <!--Y-->
 *&#x17e; <!--z-->
 *&#x17d; <!--Z-->
 * <br />as well as the words with the following diacritical marks:
 * <br />
 *
 * &auml; <!--ä-->
 * &Auml; <!--Ä-->
 * &#x103; <!--ã-->
 * &#x102; <!--Ã-->
 * &#x105; <!--±-->
 * &#x104; <!--¡-->
 *
 * &acirc; <!--â-->
 * &Acirc; <!--Â-->
 * &ccedil; <!--ç-->
 * &Ccedil; <!--Ç-->
 * &#x107; <!--æ-->
 * &#x106; <!--Æ-->
 *
 * &#x118; <!--Ê-->
 * &#x119; <!--ê-->
 * &euml; <!--ë-->
 * &Euml; <!--Ë-->
 * &icirc; <!--î-->
 * &Icirc; <!--Î-->
 *
 * &#x13a; <!--å-->
 * &#x139; <!--Å-->
 * &#x142; <!--³-->
 * &#x141; <!--£-->
 * &#x13e; <!--µ-->
 * &#x13d; <!--¥-->
 *
 * &#x144; <!--ñ-->
 * &#x143; <!--Ñ-->
 * &ocirc; <!--ô-->
 * &Ocirc; <!--Ô-->
 * &ouml; <!--ö-->
 * &Ouml; <!--Ö-->
 *
 * &#x151; <!--õ-->
 * &#x150; <!--Õ-->
 * &#x155; <!--à-->
 * &#x154; <!--À-->
 * &#x15b; <!--¶-->
 * &#x15a; <!--¦-->
 *
 * &#x15f; <!--º-->
 * &#x15e; <!--ª-->
 * &#x163; <!--þ-->
 * &#x162; <!--Þ-->
 * &#x171; <!--û-->
 * &#x170; <!--Û-->
 *
 * &uuml; <!--ü-->
 * &Uuml; <!--Ü-->
 * &#x17a; <!--¼-->
 * &#x179; <!--¬-->
 * &#x17c; <!--¿-->
 * &#x17b; <!--¯-->
 *
 * <p>Any other characters with diacritical marks as well as the characters of national alphabets which are out of range A-Z (ASCII 65-90) or a-z (ASCII 97-122)
 * are regarded as invalid in spite of the fact that they are admissible characters in UTF-8.
 * For example, it is not allowed to search by the &euro; symbol (Eurocurrency), use wildcard character * instead of that.</p>
 * <p>Since ARES as such cannot correct any error data, the ARES database may contain the words with typing errors.</p>
 * <p>Examples of the correct words in the ARES database:
 * P&#x102;C&#x102;L&#x102;U, 
 * TYBETA&#x143;SKA, 
 * &#x106;MIEL,
 * J&auml;ger, 
 * R&#x103;u, 
 * sp&oacute;&#x142;ka odpowiedzialno&#x15b;ci&#x105;, 
 * B&icirc;rc&acirc;, 
 * Fran&ccedil;oise, 
 * Jedno&#x15b;&#x107;, 
 * P&#x119;ka&#x142;a,
 * CITRO&Euml;N, 
 * O&#x13a;ga, 
 * Cie&#x144;cia&#x142;a, 
 * Kra&#x13e;, 
 * Tru&#x15b;ci&#x144;ski, 
 * D&ocirc;ng, 
 * G&ouml;tzel, 
 * V&#x155;zgna, 
 * &#x15e;im&#x15f;ir,
 * M&#x171;ller, 
 * M&uuml;ller, 
 * Gw&oacute;&#x17a;d&#x17a;, 
 * El&#x17c;bieta.
 * </p>
 *
 * <p>Examples of the typing errors in the ARES database: 
 * JECHOUTOV&#x102;, 
 * BAH&#x143;&Aacute;CI, 
 * B&#x154;&Iacute;ZOV&Aacute;,
 * JI&#x106;&Iacute;N,
 * Hlav&aacute;&ccedil;kov&aacute;,
 * &#x15a;KOLA, 
 * PROTIPO&#x179;&Aacute;RN&Iacute;.
 * </p></td></tr>
 * </table>
 *
 *<h3>Output</h3><br />
 *
 *<p>The Standard service displays basic information on the entity contained in the ARES core. The data comes from one of the sources defined as a priority source for this entity. The name of the source where the data comes from can be found in the element <span class="XMLe">Typ_registru</span>. The following data is regarded as basic: Reg.No., Business name, Legal form, Date of establishment, Address.</p> 
 *
 *<p>The element <span class="XMLe">Datum_vzniku</span> contains the date the meaning of which may differ in dependence on a type of the register. In the sources RES, AGC, RCRS, the said element contains the entity's Date of establishment or Date of registration, in CR it means Record date, in TR it means the date of registration of the first trade. The same it is with  the element <span class="XMLe">Datum_zaniku</span> when in CR it means the date of entity's deletion from CR.</p>
 *
 *<p>The element <span class="XMLe">Adresa_ARES</span> contains the address of the entity, which is standardized on the basis of data from UIR-ADR (i.e. improved names of the streets, completed numbers of houses, postcodes improved on the basis of UIR-ADR data; if the address of the entity is not assign unambiguously to the address in UIR-ADR, it would not be standardized). 
 * The element <span class="XMLe">Adresa_UIR</span> contains the data from the UIR-ADR register.</p>
 *
 *<p>The element <span class="XMLe">Adr_puv</span> (it is written only if the parameter <code>adr_puv=true</code> is used) contains information of address of entity as it is written in the data source (before the process of standardization is used).</p>
 *
 *<div class="poznamka">
 *<p><b>Note</b>:
 *The data sources give the address in different ways. Some give it in the text, some in address codes only, some give it structured and some unstructured.
 *The output element <span class="XMLe">Adr_puv</span> contains the address, if possible, structured, 
 * text data remains unchanged and any address codes are replaced with texts according to the dials of appropriate source.
 *The address of the element <span class="XMLe"> Adr_puv </span> enters into the process of address standardization during data processing in ARES.
 *The address standardization creates the standardized address contained in the element <span class="XMLe">Adresa_ARES</span>.
 *
 *</div>
 *
 *<p>Other information on an entity:
 *<br />As a part of the Standard service output you can find a list of entity's registrations in individual source registers. This information is included in the element <span class="XMLe">Priznaky_subjektu</span> together with an indication whether the given registration is valid or defunct.</p>
 *
 *<p>The letters in the element mean:
 *  <table class="TInvisible lvl2">
 *  <tr><td><code>A</code></td><td>valid registration</td></tr>
 *  <tr><td><code>Z</code></td><td>defunct registration</td></tr>
 *
 *  <tr><td><code>S</code></td><td>in position No. 6, it indicates a Group VAT Registration</td></tr>
 *  <tr><td><code>P</code></td><td>in position No. 15, it indicates suspension of the activity</td></tr>
 *  <tr><td><code>E</code>, <code>F</code></td><td>in position No. 22, it indicates that a record concerning the economic entity occurs in the Insolvency Register. Please, pay special attention to the state of the proceedings!</td></tr>
 *  <tr><td><code>N</code> (or some other character)</td><td>not found in registration</td></tr>
 *
 *  </table>
 *<div class="poznamka">
 *  <p><b>Note</b>: Some other &quot;service&quot; characters can occur.
 *  All of them should be considered as &quot;<code>N</code>&quot; character.
 *  The entity's activity is indicated only in the sources at positions from 2 to 5 and from 12 to 21.</p>
 *</div>
 *
 *<p>Individual positions in the element indicate that:
 *<table class="TInvisible lvl2">
 *
 *<tr><td><code>1</code></td><td>reserved</td></tr>
 *<tr><td><code>2</code></td><td>the entity exists in the Commercial Register</td></tr>
 *<tr><td><code>3</code></td><td>the entity exists in the Statistical Register of Economic Subjects</td></tr>
 *<tr><td><code>4</code></td><td>the entity exists in the Trade Register</td></tr>
 *<tr><td><code>5</code></td><td>the entity exists in the Register of Health Service Institutions</td></tr>
 *<tr><td><code>6</code></td><td>the entity exists in the Register of VAT Payers</td></tr>
 *
 *<tr><td><code>7</code></td><td>the entity exists in the Register of Excise Duty Payers</td></tr>
 *<tr><td><code>8</code></td><td>reserved</td></tr>
 *<tr><td><code>9</code></td><td>the entity exists in the Central Register of Bankrupts - bankruptcy</td></tr>
 *<tr><td><code>10</code></td><td>the entity exists in the Central Register of Bankrupts - compositions</td></tr>
 *<tr><td><code>11</code></td><td>the entity exists in the Central Register of State Subsidies</td></tr>
 *<tr><td><code>12</code></td><td>the entity exists in the Special register of organisations in the ARIS system</td></tr>
 *
 *<tr><td><code>13</code></td><td>the entity exists in the List of foreign exchange spots and licences</td></tr>
 *<tr><td><code>14</code></td><td>the entity exists in the Register of Church and Religious Institutions</td></tr>
 *<tr><td><code>15</code></td><td>the entity exists in the Register of Political Parties and Movements</td></tr>
 *<tr><td><code>16</code></td><td>the entity exists in the List of Insurance and Reinsurance Companies</td></tr>
 *<tr><td><code>17</code></td><td>the entity exists in the List of Responsible Actuaries</td></tr>
 *<tr><td><code>18</code></td><td>the entity exists in the List of Insurance Intermediaries and Independent Loss Adjusters</
 *td></tr>
 *
 *<tr><td><code>19</code></td><td>reserved</td></tr>
 *<tr><td><code>20</code></td><td>the entity exists in the List of Civic Associations, Guilds and Clubs</td></tr>
 *<tr><td><code>21</code></td><td>the entity exists in the Common Agricultural Register</td></tr>
 *<tr><td><code>22</code></td><td>the entity exists in the Insolvency Register</td></tr>
 *<tr><td><code>23</code></td><td>the entity exists in the Register of Schools and School Facilities</td></tr>
 *<tr><td><code>24 - 30</code></td><td>reserved</td></tr>
 *
 *</table></p>
 *
 * Date of create: May 23, 2011
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 * @version 2011.0523
 */
public class StandardService extends EmptyService{
    
    private final Map<String, Converter> converters = new HashMap<String, Converter>();
    private Logger log = Logger.getLogger(this.getClass().getName());

    public StandardService() {
        log.debug("Creating "+this.getClass().getSimpleName()+" service!");
        TypeConverter enBoolTypeConverter = new TypeConverter("en-boolean");
                
        converters.put("typ_vyhledavani", new EnumConverter(AresVyberTypEnum.FREE));
        converters.put("typ_registru", new TypeConverter("string"));
        converters.put("obchodni_firma", new LengthRangeConverter(null, 255));
        converters.put("nazev_obce", new LengthRangeConverter(2, 48));
        converters.put("kod_pf", new IntRangeIncludeConverter(0,999));
        converters.put("max_pocet", new IntRangeIncludeConverter(1,200));
        converters.put("ico", new RegExpConverter(RegExpConverter.ICO_REGEPX));
        converters.put("xml", new EnumConverter(Xml.XML));
        converters.put("jazyk", new EnumConverter(Jazyk.EN));
        converters.put("diakritika", enBoolTypeConverter);
        converters.put("adr_puv", enBoolTypeConverter);
        converters.put("aktivni", enBoolTypeConverter);
        converters.put("datum_platnosti", new TypeConverter("date"));
        converters.put("diakritika", new StringEnumConverter(new String[]{"true", "false"}));
        
        setConverters(converters);
        setObligatory(new String[]{});
        setOneOf(new String[]{"ico", "obchodni_firma"});
        
        try {
            putParam("xml", "0");
            putParam("jazyk", Jazyk.EN.value());
        } catch (ParameterNotAllowedException ex) {
            log.error("Thrown unexpected exception. This never happened!" + ex);
        }
        
        setServiceUrl("http://wwwinfo.mfcr.cz/cgi-bin/ares/darv_std.cgi");
        log.debug(this.getClass().getSimpleName()+" service created!");
    }
}
