/*
 * Copyright (C) 2011 JiangHongTiao
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.aresapi.webservice.services;

import org.apache.log4j.Logger;
import sk.lieskove.jianghongtiao.aresapi.enums.Jazyk;
import sk.lieskove.jianghongtiao.aresapi.enums.Xml;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.converter.*;
import sk.lieskove.jianghongtiao.multithreaddownloader.request.exceptions.ParameterNotAllowedException;

import java.util.HashMap;
import java.util.Map;

/**
 *<h3>Parameters:</h3>
 *    
 *    <table class="TInvisible">
 *       <tr><td class="PAlignRight"><code>kraj</code></td><td><cz>Region code or Region name</td></tr>
 *       <tr><td class="PAlignRight"><code>pobvod</code></td><td>Prague's district code or Prague's district name</td></tr>
 *
 *       <tr><td class="PAlignRight"><code>okres</code></td><td>District code or District name</td></tr>
 *       <tr><td class="PAlignRight"><code>obec</code></td><td>Town code or Town name</td></tr>
 *       <tr><td class="PAlignRight"><code>ulice</code></td><td>Street code or Street name</td></tr>
 *       <tr><td class="PAlignRight"><code>mestska_cast</code></td><td>Town district code or Town district name</td></tr>
 *       <tr><td class="PAlignRight"><code>cast_obce</code></td><td>Residential area code or Residential area name</td></tr>
 *
 *       <tr><td class="PAlignRight"><code>cislo_do_adresy</code></td><td>Land-registry number or Sequence number or both of them separated by slash</td></tr>
 *       <tr><td class="PAlignRight"><code>adresa_textem</code></td>
 *            <td>Unstructured address, i.e., an address in a form of unstructured text.<br>
 *	             Examples:<br>
 *                  	<code>Praha, Podvinny mlyn 2178<br>
 *		                      Podvinny mlyn 2178, Praha<br>
 *
 *		                      Podvinny mlyn 2178, Praha, 19000</code><br>
 *		          <ul>
 *                <li>Please, separate the particular address parts by commas</li>
 *                <li>do not place a comma between a street and land-registry number</li>
 *		            <il>the number separated by comma is regarded as a postcode</li>
 *		            <li>if the address is entered without separating commas, it has almost no chance to be found, see:<br>
 *
 *	                  a wrong entry:	Praha Podvinny mlyn 2178</li>
 *              </ul>
 *            </td>
 *       </tr>
 *       <tr><td class="PAlignRight"><code>max_pocet</code></td><td>Maximum number of addresses displayed. Permitted values: 5, 10, 20, 50, 100.</td></tr>
 *       <tr><td class="PAlignRight"><code>xml</code></td>
 *            <td><code>=0</code> - output in xml<br>
 *
 *		            <code>=1</code> - output in html, transformation performed in browser on user's PC<br>
 *		            <code>=2</code> - output in html, transformation from xml performed on server
 *            </td>
 *       </tr>
 *       <tr><td class="PAlignRight"><code>jazyk</code></td>
 *            <td><code>=cz</code> - html in Czech<br>
 *
 *		            <code>=en</code> - html in English
 *            </td>
 *       </tr>
 *       <tr><td class="PAlignRight"><code>typ</code></td><td><code>=A</code> - option activation &quot;<a href="stdadr_help.html.en#k2">Convenient addresses</a>&quot;</td></tr>
 *       <tr><td class="PAlignRight"><code>redukce</code></td><td><code>=A</code> - option activation &quot;<a href="stdadr_help.html.en#stdadr_vs">Word omission</a>&quot;</td></tr>
 *
 *       <tr><td class="PAlignRight"><code>cestina</code></td><td><code>=A</code> - option activation &quot;<a href="stdadr_help.html.en#stdadr_d">Diacritics</a>&quot;</td></tr>
 *    </table>
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 * @version 2011.0519
 */
public class AddressService extends EmptyService{
    
    private final Map<String, Converter> converters = new HashMap<String, Converter>();
    private Logger log = Logger.getLogger(this.getClass().getName());

    public AddressService() {
        log.debug("Creating address service!");
        Converter lr248 = new LengthRangeConverter(2, 48);
        Converter boolC = new TypeConverter("boolean");
        converters.put("kraj", new LengthRangeConverter(null, 32));
        converters.put("pobvod", lr248);
        converters.put("okres", lr248);
        converters.put("obec", lr248);
        converters.put("ulice", new LengthRangeConverter(1, 48));
        converters.put("mestska_cast", lr248);
        converters.put("cast_obce", lr248);						
        converters.put("cislo_do_adresy", new LengthRangeConverter(1, 15));									
        converters.put("adresa_textem", new LengthRangeConverter(null, 255));											
        converters.put("max_pocet", new TypeConverter("short"));
        converters.put("typ", boolC);
        converters.put("redukce", boolC);														
        converters.put("cestina", boolC);
        converters.put("xml", new EnumConverter(Xml.XML));
        converters.put("jazyk", new EnumConverter(Jazyk.EN));
        converters.put("ver", new RegExpConverter(RegExpConverter.VERSION_REGEPX));
        setConverters(converters);
        String[] obligatory = new String[]{"xml"};
        setObligatory(obligatory);
        String[] oneOf = new String[]{"kraj", "pobvod", "okres", "obec", "ulice", 
            "mestska_cast", "cast_obce", "cislo_do_adresy", "adresa_textem"};
        setOneOf(oneOf);
        
        try {
            putParam("xml", "0");
            putParam("jazyk", Jazyk.EN.value());
        } catch (ParameterNotAllowedException ex) {
            log.error("Thrown unexpected exception. This never happened!" + ex);
        }
        
        setServiceUrl("http://wwwinfo.mfcr.cz/cgi-bin/ares/darv_adr.cgi");
        log.debug("Address service created!");
    }
    
}
