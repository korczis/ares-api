/*
 *  Copyright (C) 2011 JiangHongTiao <jjurco.sk_gmail.com>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.aresapi.websearch;

import org.joda.time.IllegalFieldValueException;
import sk.lieskove.jianghongtiao.aresapi.response.obj.AresOdpovedi;

/**
 * Date of create: May 15, 2011
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 * @version 2011.0515
 */
public interface AresFindPeople {

    /**
     * =cestina - jméno osoby je zadáno s diakritickými znaménky
     * (ve formuláři: Diakritika: česká), bez tohoto parametru
     * (tj. Diakritika: ASCII) se předpokládá, že ve jméně diakr. znaménka nejsou
     */
    public static enum Diakritika {

        CESTINA("cestina"), ASCII("");
        private String value;

        Diakritika(String value) {
            this.value = value;
        }

        public static Diakritika fromValue(String v) {
            for (Diakritika c : Diakritika.values()) {
                if (c.value.equals(v)) {
                    return c;
                }
            }
            throw new IllegalArgumentException(v);
        }

        @Override
        public String toString() {
            return valueOf(super.toString()).value;
        }
    };

    /**
     * Jak mají být setříděné vracené subjekty:
     * =ZADNE - žádné setřídění
     * =RC - setříděno dle rodného čísla
     * =JMENO - setříděno dle jména osoby
     */
    public static enum Setrid {

        ZADNE("ZADNE"), RC("RC"), JMENO("JMENO");
        private String value;

        Setrid(String value) {
            this.value = value;
        }

        public static Setrid fromValue(String v) {
            for (Setrid c : Setrid.values()) {
                if (c.value.equals(v)) {
                    return c;
                }
            }
            throw new IllegalArgumentException(v);
        }

        @Override
        public String toString() {
            return valueOf(super.toString()).value;
        }
    }

    /**
     * =0 - výstup bude v xml
     * =1 - výstup bude v html, transformace budou v prohlížeči na PC
     * =2 - výstup bude v html, transformace z xml proběhne na serveru
     */
    public static enum XmlVystup {

        XML("0"), HTML_TRANSFORM_PC("1"), HTML_TRANSFORM_SERVER("2");
        private String value;

        XmlVystup(String value) {
            this.value = value;
        }

        public static XmlVystup fromValue(String v) {
            for (XmlVystup c : XmlVystup.values()) {
                if (c.value.equals(v)) {
                    return c;
                }
            }
            throw new IllegalArgumentException(v);
        }

        @Override
        public String toString() {
            return valueOf(super.toString()).value;
        }
    };

    /**
     * =cz - html bude v češtině
     * =en - html bude v angličtině
     */
    public static enum Jazyk {

        CZ("CZ"), EN("EN");
        private String value;

        Jazyk(String value) {
            this.value = value;
        }

        public static Jazyk fromValue(String v) {
            for (Jazyk c : Jazyk.values()) {
                if (c.value.equals(v)) {
                    return c;
                }
            }
            throw new IllegalArgumentException(v);
        }

        @Override
        public String toString() {
            return valueOf(super.toString()).value;
        }
    };

    /**
     * výběr dle kódů angažmá
     * =všechna - zobrazí všechny nalezené subjekty
     * =výběr - jen aktivní subjekty
     */
    public static enum Angazma {

        VYBER("výběr"), VSECHNA("všechna");
        private String value;

        Angazma(String value) {
            this.value = value;
        }

        public static Angazma fromValue(String v) {
            for (Angazma c : Angazma.values()) {
                if (c.value.equals(v)) {
                    return c;
                }
            }
            throw new IllegalArgumentException(v);
        }

        @Override
        public String toString() {
            return valueOf(super.toString()).value;
        }

    };

    /**
     * kód angažmá. Při více angažmá se oddělují +.
     * Přehled kódů angažmá:
     * (200-238 jsou angažmá z OR, 1800-1843 jsou z ISPOZ)
     * =200 - Podnikatel z OR
     * =201 - Člen statutárního orgánu
     * =202 - Likvidátor
     * =203 - Prokurista
     * =204 - Člen dozorčí rady
     * =205 - Jediný akcionář
     * =206 - Člen družstva s vkladem
     * =207 - Společník bez vkladu
     * =208 - Společník s vkladem
     * =209 - Komplementář
     * =210 - Komanditista
     * =211 - Správce konkursu
     * =212 - Zástupce správce konkursu
     * =214 - Zakladatel o.p.s.
     * =215 - Zřizovatel odštěpného závodu
     * =219 - Podílník
     * =220 - Revizor
     * =221 - Zřizovatel nadace
     * =222 - Statutár - vedoucí odštěpného závodu
     * =223 - Vedoucí odštěpného závodu
     * =224 - Zvláštní správce konkursu
     * =225 - Předběžný správce konkursní podstaty
     * =227 - Člen statutárního orgánu společnosti
     * =228 - Člen statutárního orgánu komplementářů
     * =229 - Člen statutárního orgánu představenstva
     * =230 - Člen představenstva
     * =231 - Člen správní rady
     * =232 - Oprávněná osoba nadace
     * =233 - Oprávněná osoba nadačního fondu
     * =234 - Nástupce zřizovatele
     * =235 - Zřizovatel příspěvkové organizace
     * =236 - Člen sdružení
     * =237 - Člen statutárního orgánu zřizovatele - Z
     * =238 - Člen kontrolní komise - Z
     * =400 - Podnikatel z RŽP
     * =401 - Statutár
     * =402 - Vedoucí org. složky
     * =1800 - Podnikatel z ISPOZ
     * =1801 - Člen statutárního orgánu
     * =1802 - Odpovědný zástupce
     */
    public enum Angaz {

        A_200("200"), A_201("201"), A_202("202"), A_203("203"),
        A_204("204"), A_205("205"), A_206("206"),
        A_207("207"), A_208("208"), A_209("209"), A_210("210"), A_211("211"),
        A_212("212"), A_214("214"), A_215("215"), A_219("219"), A_220("220"),
        A_221("221"), A_222("222"), A_223("223"), A_224("224"), A_225("225"),
        A_227("227"), A_228("228"), A_229("229"), A_230("230"), A_231("231"),
        A_232("232"), A_233("233"), A_234("234"), A_235("235"), A_236("236"),
        A_237("237"), A_238("238"), A_400("400"), A_401("401"), A_402("402"),
        A_1800("1800"), A_1801("1801"), A_1802("1802");
        private String value;

        Angaz(String value) {
            this.value = value;
        }

        public static Angaz fromValue(String v) {
            for (Angaz c : Angaz.values()) {
                if (c.value.equals(v)) {
                    return c;
                }
            }
            throw new IllegalArgumentException(v);
        }

        @Override
        public String toString() {
            return super.toString().substring(2);
        }
    };

    /**
     * maximální počet vracených subjektů. Povolené hodnoty: 200, 500, 1000.
     */
    public static enum MaxPoc {

        MAX_200("200"), MAX_500("500"), MAX_1000("1000");
        private String value;

        MaxPoc(String value) {
            this.value = value;
        }

        public static MaxPoc fromValue(String v) {
            for (MaxPoc c : MaxPoc.values()) {
                if (c.value.equals(v)) {
                    return c;
                }
            }
            throw new IllegalArgumentException(v);
        }

        @Override
        public String toString() {
            return super.toString().substring(4);
        }
    };

    /**
     * název ulice v adrese
     */
    String getAdresa();

    /**
     * kód angažmá. Při více angažmá se oddělují +.
     * Přehled kódů angažmá:
     * (200-238 jsou angažmá z OR, 1800-1843 jsou z ISPOZ)
     * =200 - Podnikatel z OR
     * =201 - Člen statutárního orgánu
     * =202 - Likvidátor
     * =203 - Prokurista
     * =204 - Člen dozorčí rady
     * =205 - Jediný akcionář
     * =206 - Člen družstva s vkladem
     * =207 - Společník bez vkladu
     * =208 - Společník s vkladem
     * =209 - Komplementář
     * =210 - Komanditista
     * =211 - Správce konkursu
     * =212 - Zástupce správce konkursu
     * =214 - Zakladatel o.p.s.
     * =215 - Zřizovatel odštěpného závodu
     * =219 - Podílník
     * =220 - Revizor
     * =221 - Zřizovatel nadace
     * =222 - Statutár - vedoucí odštěpného závodu
     * =223 - Vedoucí odštěpného závodu
     * =224 - Zvláštní správce konkursu
     * =225 - Předběžný správce konkursní podstaty
     * =227 - Člen statutárního orgánu společnosti
     * =228 - Člen statutárního orgánu komplementářů
     * =229 - Člen statutárního orgánu představenstva
     * =230 - Člen představenstva
     * =231 - Člen správní rady
     * =232 - Oprávněná osoba nadace
     * =233 - Oprávněná osoba nadačního fondu
     * =234 - Nástupce zřizovatele
     * =235 - Zřizovatel příspěvkové organizace
     * =236 - Člen sdružení
     * =237 - Člen statutárního orgánu zřizovatele - Z
     * =238 - Člen kontrolní komise - Z
     * =400 - Podnikatel z RŽP
     * =401 - Statutár
     * =402 - Vedoucí org. složky
     * =1800 - Podnikatel z ISPOZ
     * =1801 - Člen statutárního orgánu
     * =1802 - Odpovědný zástupce
     */
    Angaz[] getAngaz();

    /**
     * výběr dle kódů angažmá
     * =všechna - zobrazí všechny nalezené subjekty
     * =výběr - jen aktivní subjekty
     */
    Angazma getAngazma();

    /**
     * =cestina - jméno osoby je zadáno s diakritickými znaménky
     * (ve formuláři: Diakritika: česká), bez tohoto parametru
     * (tj. Diakritika: ASCII) se předpokládá, že ve jméně diakr. znaménka nejsou
     */
    Diakritika getCestina();

    /**
     * číslo orientační v adrese
     */
    String getCis_or();

    /**
     * číslo popisné v adrese
     */
    String getCis_po();

    /**
     * =cz - html bude v češtině
     * =en - html bude v angličtině
     */
    Jazyk getJazyk();

    /**
     * jméno a příjmení osoby
     */
    String getJmeno();

    /**
     * maximální počet vracených subjektů. Povolené hodnoty: 200, 500, 1000.
     */
    MaxPoc getMaxpoc();

    /**
     * název obce
     */
    String getObec();

    /**
     * číslo PSČ
     */
    String getPsc();

    /**
     * celé rodné číslo bez lomítka (Při zadání RČ jsou ostatní vyhledávací kritéria nadbytečná.)
     */
    String getRc();

    /**
     * Jak mají být setříděné vracené subjekty:
     * =ZADNE - žádné setřídění
     * =RC - setříděno dle rodného čísla
     * =JMENO - setříděno dle jména osoby
     */
    Setrid getSetrid();

    /**
     * =0 - výstup bude v xml
     * =1 - výstup bude v html, transformace budou v prohlížeči na PC
     * =2 - výstup bude v html, transformace z xml proběhne na serveru
     */
    XmlVystup getXml();

    /**
     * název ulice v adrese
     * @param adresa set address to search for. When the string is empty or null, address is removed from search
     * @throws IllegalArgumentException when address is longer than 45 characters
     */
    void setAdresa(String adresa) throws IllegalArgumentException;

    /**
     * kód angažmá. Při více angažmá se oddělují +.
     * Přehled kódů angažmá:
     * (200-238 jsou angažmá z OR, 1800-1843 jsou z ISPOZ)
     * =200 - Podnikatel z OR
     * =201 - Člen statutárního orgánu
     * =202 - Likvidátor
     * =203 - Prokurista
     * =204 - Člen dozorčí rady
     * =205 - Jediný akcionář
     * =206 - Člen družstva s vkladem
     * =207 - Společník bez vkladu
     * =208 - Společník s vkladem
     * =209 - Komplementář
     * =210 - Komanditista
     * =211 - Správce konkursu
     * =212 - Zástupce správce konkursu
     * =214 - Zakladatel o.p.s.
     * =215 - Zřizovatel odštěpného závodu
     * =219 - Podílník
     * =220 - Revizor
     * =221 - Zřizovatel nadace
     * =222 - Statutár - vedoucí odštěpného závodu
     * =223 - Vedoucí odštěpného závodu
     * =224 - Zvláštní správce konkursu
     * =225 - Předběžný správce konkursní podstaty
     * =227 - Člen statutárního orgánu společnosti
     * =228 - Člen statutárního orgánu komplementářů
     * =229 - Člen statutárního orgánu představenstva
     * =230 - Člen představenstva
     * =231 - Člen správní rady
     * =232 - Oprávněná osoba nadace
     * =233 - Oprávněná osoba nadačního fondu
     * =234 - Nástupce zřizovatele
     * =235 - Zřizovatel příspěvkové organizace
     * =236 - Člen sdružení
     * =237 - Člen statutárního orgánu zřizovatele - Z
     * =238 - Člen kontrolní komise - Z
     * =400 - Podnikatel z RŽP
     * =401 - Statutár
     * =402 - Vedoucí org. složky
     * =1800 - Podnikatel z ISPOZ
     * =1801 - Člen statutárního orgánu
     * =1802 - Odpovědný zástupce
     * @param angaz array of angaz to set
     */
    void setAngaz(Angaz[] angaz);

    /**
     * výběr dle kódů angažmá
     * =všechna - zobrazí všechny nalezené subjekty
     * =výběr - jen aktivní subjekty
     * @param angazma {@link #Angazma}
     */
    void setAngazma(Angazma angazma);

    /**
     * =cestina - jméno osoby je zadáno s diakritickými znaménky
     * (ve formuláři: Diakritika: česká), bez tohoto parametru
     * (tj. Diakritika: ASCII) se předpokládá, že ve jméně diakr. znaménka nejsou
     *
     */
    void setCestina(Diakritika cestina);

    /**
     * číslo orientační v adrese
     * Číslo orientačního, povoleny číslicové znaky, přípustný interval hodnot
     * 1a - 999z. (do 17.2.2010 byl integer na 4 znaky)
     */
    void setCis_or(String cis_or) throws IllegalArgumentException;

    /**
     * číslo popisné v adrese
     * range: 1-9999
     */
    void setCis_po(String cis_po);

    /**
     * =cz - html bude v češtině
     * =en - html bude v angličtině
     */
    void setJazyk(Jazyk jazyk);

    /**
     * jméno a příjmení osoby
     * max Length: 25
     * @param jmeno set name of searched person
     */
    void setJmeno(String jmeno) throws IllegalArgumentException;

    /**
     * maximální počet vracených subjektů. Povolené hodnoty: 200, 500, 1000.
     * @param maxpoc set maximal number of returned results
     */
    void setMaxpoc(MaxPoc maxpoc);

    /**
     * název obce
     * max. length: 45
     */
    void setObec(String obec) throws IllegalArgumentException;

    /**
     * číslo PSČ
     * length: 5; reg. exp. pattern: \d\d\d\d\d
     */
    void setPsc(String psc) throws IllegalArgumentException;

    /**
     * celé rodné číslo bez lomítka (Při zadání RČ jsou ostatní vyhledávací kritéria nadbytečná.)
     * @param rc set birth number of person. When this parameter is set, there is no
     * need of other parameters. 
     * @throws NumberFormatException when birth number is before year 54 and is 10 characters long
     * @throws IllegalArgumentException when  when birth number contains non-numeric values
     * @throws FutureDateException when the birth number is not past date, but future.
     * Cannot search for somebody who is not alive!
     */
    void setRc(String rc) throws NumberFormatException, IllegalArgumentException,
            IllegalFieldValueException;

    /**
     * rc1	první, datumová část rodného čísla
     * rc2	druhá část rodného čísla
     */
    void setRc(String predLomenom, String zaLomenom) throws
            NumberFormatException,
            IllegalArgumentException, IllegalFieldValueException;

    /**
     * Jak mají být setříděné vracené subjekty:
     * =ZADNE - žádné setřídění
     * =RC - setříděno dle rodného čísla
     * =JMENO - setříděno dle jména osoby
     */
    void setSetrid(Setrid setrid);

    /**
     * =0 - výstup bude v xml
     * =1 - výstup bude v html, transformace budou v prohlížeči na PC
     * =2 - výstup bude v html, transformace z xml proběhne na serveru
     */
    void setXml(XmlVystup xml);

    /**
     * find people in ARES system by set parameters
     * @return response from ARES as object, if exception is thrown returns null
     */
    AresOdpovedi find();

    /**
     * find user by name specified as parameter
     * @param name name of the searched person
     * @return return results like function {@link #find()} as when before was set name
     */
    AresOdpovedi findByName(String name);
}
