/*
 * Copyright (C) 2011 JiangHongTiao
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.aresapi.enums;

/**
 * Date of create: Oct 10, 2011
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 * @version 2011.1010
 */
public enum VersionEnum {
    
    Ver_100("1.0.0"),
    Ver_101("1.0.1"),
    Ver_102("1.0.2"),
    Ver_103("1.0.3"),
    Ver_104("1.0.4"),
    Ver_105("1.0.5");

    private final String value;
    
    VersionEnum(String v) {
        value = v;
    }
    
    public String value() {
        return value;
    }
    
    public VersionEnum fromValue(String v) {
        for (VersionEnum c : VersionEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException("Value '" + v
                + "' is not correct value for type "
                + VersionEnum.class.getName());
    }
    
    public boolean containsValue(String v) {
        for (VersionEnum c : VersionEnum.values()) {
            if (c.value.equals(v)) {
                return true;
            }
        }
        return false;
    }
}
