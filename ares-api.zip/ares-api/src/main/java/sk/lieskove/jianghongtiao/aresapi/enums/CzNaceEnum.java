/*
 * Copyright (C) 2011 JiangHongTiao
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.aresapi.enums;

import sk.lieskove.jianghongtiao.common.enums.EnumInterface;

/**
 * Date of create: May 22, 2011
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 * @version 2011.0522
 */
public enum CzNaceEnum implements EnumInterface, Comparable<CzNaceEnum> {

    CZNACE_000000("000000", "Nezarazeno"),
CZNACE_010000("010000", "Rostlinna a zivocisna vyroba, myslivost a souvisejici cinnosti"),
CZNACE_020000("020000", "Lesnictvi a tezba dreva"),
CZNACE_030000("030000", "Rybolov a akvakultura"),
CZNACE_050000("050000", "Tezba a uprava cerneho a hnedeho uhli"),
CZNACE_060000("060000", "Tezba ropy a zemniho plynu"),
CZNACE_070000("070000", "Tezba a uprava rud"),
CZNACE_080000("080000", "Ostatni tezba a dobyvani"),
CZNACE_090000("090000", "Podpurne cinnosti pri tezbe"),
CZNACE_100000("100000", "Vyroba potravinarskych vyrobku"),
CZNACE_110000("110000", "Vyroba napoju"),
CZNACE_120000("120000", "Vyroba tabakovych vyrobku"),
CZNACE_130000("130000", "Vyroba textilii"),
CZNACE_140000("140000", "Vyroba odevu"),
CZNACE_150000("150000", "Vyroba usni a souvisejicich vyrobku"),
CZNACE_160000("160000", "Zpracovani dreva, vyroba drevenych, korkovych, proutenych a slamenych vyrobku, krome nabytku"),
CZNACE_170000("170000", "Vyroba papiru a vyrobku z papiru"),
CZNACE_180000("180000", "Tisk a rozmnozovani nahranych nosicu"),
CZNACE_190000("190000", "Vyroba koksu a rafinovanych ropnych produktu"),
CZNACE_200000("200000", "Vyroba chemickych latek a chemickych pripravku"),
CZNACE_210000("210000", "Vyroba zakladnich farmaceutickych vyrobku a farmaceutickych pripravku"),
CZNACE_220000("220000", "Vyroba pryzovych a plastovych vyrobku"),
CZNACE_230000("230000", "Vyroba ostatnich nekovovych mineralnich vyrobku"),
CZNACE_240000("240000", "Vyroba zakladnich kovu, hutni zpracovani kovu; slevarenstvi"),
CZNACE_250000("250000", "Vyroba kovovych konstrukci a kovodelnych vyrobku, krome stroju a zarizeni"),
CZNACE_260000("260000", "Vyroba pocitacu, elektronickych a optickych pristroju a zarizeni"),
CZNACE_270000("270000", "Vyroba elektrickych zarizeni"),
CZNACE_280000("280000", "Vyroba stroju a zarizeni j. n."),
CZNACE_290000("290000", "Vyroba motorovych vozidel (krome motocyklu), privesu a navesu"),
CZNACE_300000("300000", "Vyroba ostatnich dopravnich prostredku a zarizeni"),
CZNACE_310000("310000", "Vyroba nabytku"),
CZNACE_320000("320000", "Ostatni zpracovatelsky prumysl"),
CZNACE_330000("330000", "Opravy a instalace stroju a zarizeni"),
CZNACE_350000("350000", "Vyroba a rozvod elektriny, plynu, tepla a klimatizovaneho vzduchu"),
CZNACE_360000("360000", "Shromazdovani, uprava a rozvod vody"),
CZNACE_370000("370000", "Cinnosti souvisejici s odpadnimi vodami"),
CZNACE_380000("380000", "Shromazdovani, sber a odstranovani odpadu, uprava odpadu k dalsimu vyuziti"),
CZNACE_390000("390000", "Sanace a jine cinnosti souvisejici s odpady"),
CZNACE_410000("410000", "Vystavba budov"),
CZNACE_420000("420000", "Inzenyrske stavitelstvi"),
CZNACE_430000("430000", "Specializovane stavebni cinnosti"),
CZNACE_450000("450000", "Velkoobchod, maloobchod a opravy motorovych vozidel"),
CZNACE_460000("460000", "Velkoobchod, krome motorovych vozidel"),
CZNACE_470000("470000", "Maloobchod, krome motorovych vozidel"),
CZNACE_490000("490000", "Pozemni a potrubni doprava"),
CZNACE_500000("500000", "Vodni doprava"),
CZNACE_510000("510000", "Letecka doprava"),
CZNACE_520000("520000", "Skladovani a vedlejsi cinnosti v doprave"),
CZNACE_530000("530000", "Postovni a kuryrni cinnosti"),
CZNACE_550000("550000", "Ubytovani"),
CZNACE_560000("560000", "Stravovani a pohostinstvi"),
CZNACE_580000("580000", "Vydavatelske cinnosti"),
CZNACE_590000("590000", "Cinnosti v oblasti filmu, videozaznamu a televiznich programu, porizovani zvukovych nahravek a hudebni vydavatelske cinnosti"),
CZNACE_600000("600000", "Tvorba programu a vysilani"),
CZNACE_610000("610000", "Telekomunikacni cinnosti"),
CZNACE_620000("620000", "Cinnosti v oblasti informacnich technologii"),
CZNACE_630000("630000", "Informacni cinnosti"),
CZNACE_640000("640000", "Financni zprostredkovani, krome pojistovnictvi a penzijniho financovani"),
CZNACE_650000("650000", "Pojisteni, zajisteni a penzijni financovani, krome povinneho socialniho zabezpeceni"),
CZNACE_660000("660000", "Ostatni financni cinnosti"),
CZNACE_680000("680000", "Cinnosti v oblasti nemovitosti"),
CZNACE_690000("690000", "Pravni a ucetnicke cinnosti"),
CZNACE_700000("700000", "Cinnosti vedeni podniku; poradenstvi v oblasti rizeni"),
CZNACE_710000("710000", "Architektonicke a inzenyrske cinnosti; technicke zkousky a analyzy"),
CZNACE_720000("720000", "Vyzkum a vyvoj"),
CZNACE_730000("730000", "Reklama a pruzkum trhu"),
CZNACE_740000("740000", "Ostatni profesni, vedecke a technicke cinnosti"),
CZNACE_750000("750000", "Veterinarni cinnosti"),
CZNACE_770000("770000", "Cinnosti v oblasti pronajmu a operativniho leasingu"),
CZNACE_780000("780000", "Cinnosti souvisejici se zamestnanim"),
CZNACE_790000("790000", "Cinnosti cestovnich agentur, kancelari a jine rezervacni a souvisejici cinnosti"),
CZNACE_800000("800000", "Bezpecnostni a patraci cinnosti"),
CZNACE_810000("810000", "Cinnosti souvisejici se stavbami a upravou krajiny"),
CZNACE_820000("820000", "Administrativni, kancelarske a jine podpurne cinnosti pro podnikani"),
CZNACE_840000("840000", "Verejna sprava a obrana; povinne socialni zabezpeceni"),
CZNACE_850000("850000", "Vzdelavani"),
CZNACE_860000("860000", "Zdravotni pece"),
CZNACE_870000("870000", "Ustavni socialni pece"),
CZNACE_880000("880000", "Mimoustavni socialni pece"),
CZNACE_900000("900000", "Tvurci, umelecke a zabavni cinnosti"),
CZNACE_910000("910000", "Cinnosti knihoven, archivu, muzei a jinych kulturnich zarizeni"),
CZNACE_920000("920000", "Cinnosti heren, kasin a sazkovych kancelari"),
CZNACE_930000("930000", "Sportovni, zabavni a rekreacni cinnosti"),
CZNACE_940000("940000", "Cinnosti organizaci sdruzujicich osoby za ucelem prosazovani spolecnych zajmu"),
CZNACE_950000("950000", "Opravy pocitacu a vyrobku pro osobni potrebu a prevazne pro domacnost"),
CZNACE_960000("960000", "Poskytovani ostatnich osobnich sluzeb"),
CZNACE_970000("970000", "Cinnosti domacnosti jako zamestnavatelu domaciho personalu"),
CZNACE_980000("980000", "Cinnosti domacnosti produkujicich blize neurcene vyrobky a sluzby pro vlastni potrebu");
    
    private final String description;
    private final String code;

    CzNaceEnum(String code, String description) {
        this.description = description;
        this.code = code;
    }
    
    public String description(){
        return description;
    }

    @Override
    public String value() {
        return code;
    }
    
    public String code() {
        return code;
    }

    @Override
    public CzNaceEnum fromValue(String v) {
        for (CzNaceEnum c : CzNaceEnum.values()) {
            if (c.code.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException("Value '" + v
                + "' is not correct value for type "
                + CzNaceEnum.class.getName());
    }

    @Override
    public boolean containsValue(String v) {
        for (CzNaceEnum c : CzNaceEnum.values()) {
            if (c.code.equals(v)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return "CzNaceEnum{" + "code=" + code + '}';
    }
    
}
