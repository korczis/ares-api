/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.lieskove.jianghongtiao.common.utils;

import org.apache.log4j.Logger;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/**
 * 
 * @author xjuraj e-mail: jjurco.sk_gmail.com
 */
public class Array implements Serializable {

    private transient Logger log = Logger.getLogger(Array.class);
    private transient PropertiesUtils pu = new PropertiesUtils(Array.class);

    public static String[] stringsToLower(String... strings) {
        String[] result = new String[strings.length];
        for (int i = 0; i < strings.length; i++) {
            result[i] = strings[i].toLowerCase();
        }
        return result;
    }

    public static String[] enums2Values(Enum... strings) {
        String[] result = new String[strings.length];
        for (int i = 0; i < strings.length; i++) {
            result[i] = strings[i].name();
        }
        return result;
    }

    public static int getMaxValue(int... numbers) {
        int maxValue = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] > maxValue) {
                maxValue = numbers[i];
            }
        }
        return maxValue;
    }

    /**
     * pick random subset from list of objects
     * @param set original list
     * @param subsetSize new subset size
     * @return random subset of items of size <code>subsetSize</code>
     */
    public static <T> List<T> randomSubset(List<T> set, int subsetSize) {
        List<T> list = new LinkedList<T>(set);
        Collections.shuffle(list);
        Random rand = new Random();
        int index = Math.abs(rand.nextInt(set.size())/2);
        return list.subList(0, Math.min(subsetSize, set.size()));
    }
    
    /**
     * get maximal size of list from collection of lists
     * @param items list of lists
     * @return size of the maximal list
     */
    public static <T> int getMaxListSize(Collection<List<T>> items){
        int max = 0;
        for (List list : items) {
            if(list.size() > max){
                max = list.size();
            }
        }
        return max;
    }
    
    /**
     * count total size of all lists in collection
     * @param items collection of lists
     * @return number of items in all lists in collection
     */
    public static <T> int countListsSize(Collection<List<T>> items){
        int count = 0;
        for (List list : items) {
            count += list.size();
        }
        return count;
    }
    
    /**
     * class cast list
     * @param <T> result list type
     * @param list list of objects
     * @param t result class
     * @return class casted list
     */
    public static <T> List<T> castList(List list, Class<T> t){
        List<T> result = new ArrayList<T>();
        for (Object object : list) {
            result.add((T)object);
        }
        return result;
    }
}
