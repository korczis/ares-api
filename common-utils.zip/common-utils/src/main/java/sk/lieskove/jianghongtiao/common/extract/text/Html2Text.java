/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.lieskove.jianghongtiao.common.extract.text;

import org.apache.log4j.Logger;
import org.htmlcleaner.BrowserCompactXmlSerializer;
import org.htmlcleaner.CleanerProperties;
import org.htmlcleaner.HtmlCleaner;
import org.htmlcleaner.TagNode;
import sk.lieskove.jianghongtiao.common.utils.FileUtils;
import sk.lieskove.jianghongtiao.common.utils.PropertiesUtils;
import sk.lieskove.jianghongtiao.common.utils.text.StringUtils;
import sk.lieskove.jianghongtiao.common.utils.xml.Transformation;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;

/**
 * Extract text from the HTML file
 * @author xjuraj e-mail: jjurco.sk_gmail.com
 */
public class Html2Text implements Serializable, TextExtractor {

    private transient Logger log = Logger.getLogger(Html2Text.class);
    private transient PropertiesUtils pu = new PropertiesUtils(Html2Text.class);

    @Override
    public String extractText(File inputFile) {
        try {
            log.debug("Enter Html2Text with file: " + inputFile.getAbsolutePath());
            String read = FileUtils.read(inputFile);
            return extractText(read);
        } catch (IOException ex) {
            log.error("Cannot read file: " + inputFile.getAbsolutePath());
        }
        return null;
    }

    public String extractText(String inputString) {
        try {
            log.debug("Enter Html2Text");
            HtmlCleaner cleaner = new HtmlCleaner();
            CleanerProperties properties = cleaner.getProperties();
            properties.setPruneTags("script,style,noscript,fb:like");
            properties.setNamespacesAware(false);
            TagNode clean = cleaner.clean(inputString);
            BrowserCompactXmlSerializer serializer = new BrowserCompactXmlSerializer(properties);
            String asString = serializer.getAsString(clean, "UTF-8");
            String applyTemplate = Transformation.applyTemplate(asString,
                    new File("resources/transform/preprocessing/Html2TextExtract.xsl"));
            String trailingSpaces = StringUtils.trailingSpaces(applyTemplate);
            String extractedText = trailingSpaces.trim();
            log.debug("Html2Text extracted: " + extractedText.length() + " characters.");
            return extractedText.trim();
        } catch (IOException ex) {
            log.error("IO exception for string: "+inputString);
        }
        return null;
    }
}
