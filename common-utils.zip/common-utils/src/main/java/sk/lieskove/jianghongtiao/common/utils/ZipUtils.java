/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.lieskove.jianghongtiao.common.utils;

import org.apache.log4j.Logger;

import java.io.*;
import java.util.zip.Adler32;
import java.util.zip.CheckedOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Zip utilities
 * @author xjuraj e-mail: jjurco.sk_gmail.com
 */
public class ZipUtils implements Serializable {

    private static transient Logger log = Logger.getLogger(ZipUtils.class);
    private static final int BUFFER = 2048;

    public static File zipFiles(File outputFile, File... files) {
        FileOutputStream dest = null;
        BufferedInputStream origin = null;
        try {
            dest = new FileOutputStream(outputFile);
            CheckedOutputStream checksum = new CheckedOutputStream(dest, new Adler32());
            ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(checksum));
//            out.setMethod(ZipOutputStream.DEFLATED);
            for (File file : files) {
                if(file == null) continue;
                byte data[] = new byte[BUFFER];
                FileInputStream fi = null;
                try {
                    log.debug("ZIP add: " + file);
                    fi = new FileInputStream(file);
                    origin = new BufferedInputStream(fi, BUFFER);
                    ZipEntry entry = new ZipEntry(file.getName());
                    out.putNextEntry(entry);
                    int count;
                    while ((count = origin.read(data, 0, BUFFER)) != -1) {
                        out.write(data, 0, count);
                    }

                    origin.close();
                } catch (FileNotFoundException ex) {
                    log.error("File not found: " + file.getAbsolutePath());
                } catch (IOException ex) {
                    log.error("IO exception in file: " + file.getAbsolutePath());
                } finally {
                    try {
                        fi.close();
                    } catch (IOException ex) {
                        log.error("Cannot close file: " + file.getAbsolutePath());
                    }
                }
            }
            out.close();
            return outputFile;
        } catch (FileNotFoundException ex) {
            log.error("ZIP output file was not found: " + outputFile.getAbsolutePath());
        } catch (IOException ex) {
            log.error("IO exception in ZIP output file: " + outputFile.getAbsolutePath());
        } finally {
            try {
                dest.close();
            } catch (IOException ex) {
                log.error("Cannot close output stream for file: " + outputFile.getAbsolutePath());
            }
        }
        return null;
    }

    public static File zipFile(File path, File outputFile) {
        FileOutputStream dest = null;
        BufferedInputStream origin = null;
        try {
            dest = new FileOutputStream(outputFile);
            CheckedOutputStream checksum = new CheckedOutputStream(dest, new Adler32());
            ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(checksum));
//            out.setMethod(ZipOutputStream.DEFLATED);
            byte data[] = new byte[BUFFER];
            FileInputStream fi = null;
            try {
                log.debug("ZIP add: " + path);
                fi = new FileInputStream(path);
                origin = new BufferedInputStream(fi, BUFFER);
                ZipEntry entry = new ZipEntry(path.getName());
                out.putNextEntry(entry);
                int count;
                while ((count = origin.read(data, 0, BUFFER)) != -1) {
                    out.write(data, 0, count);
                }
                origin.close();
            } catch (FileNotFoundException ex) {
                log.error("File not found: " + path.getAbsolutePath());
            } catch (IOException ex) {
                log.error("IO exception in file: " + path.getAbsolutePath());
            } finally {
                try {
                    fi.close();
                } catch (IOException ex) {
                    log.error("Cannot close file: " + path.getAbsolutePath());
                }
            }
            out.close();
            return outputFile;
        } catch (FileNotFoundException ex) {
            log.error("ZIP output file was not found: " + outputFile.getAbsolutePath());
        } catch (IOException ex) {
            log.error("IO exception in ZIP output file: " + outputFile.getAbsolutePath());
        } finally {
            try {
                dest.close();
            } catch (IOException ex) {
                log.error("Cannot close output stream for file: " + outputFile.getAbsolutePath());
            }
        }
        return null;
    }
}
