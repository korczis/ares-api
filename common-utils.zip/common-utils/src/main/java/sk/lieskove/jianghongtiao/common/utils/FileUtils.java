/*
 *  Copyright (C) 2011 JiangHongTiao <jjurco.sk_gmail.com>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.common.utils;

import org.apache.log4j.Logger;

import java.io.*;
import java.util.Scanner;

/**
 * Date of create: May 15, 2011
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 * @version 2011.0515
 */
public class FileUtils {

    private static PropertiesUtils pu = new PropertiesUtils(FileUtils.class);
    private static Logger log = Logger.getLogger(FileUtils.class);

    public static void write(File fFileName, String text) throws IOException {
        write(fFileName, "UTF-8", text);
    }

    /** Write fixed content to the given file. */
    public static void write(File fFileName, String fEncoding, String text)
            throws IOException {
        Writer out = new OutputStreamWriter(new FileOutputStream(fFileName),
                fEncoding);
        try {
            out.write(text);
        } finally {
            out.close();
        }
    }

    public static void appendLine(String file, String appendString) {
        try {
            // Create file 
            FileWriter fstream = new FileWriter(file, true);
            BufferedWriter out = new BufferedWriter(fstream);
            out.write(appendString);
            //Close the output stream
            out.close();
        } catch (Exception e) {//Catch exception if any
            System.err.println("Error: " + e.getMessage());
        }
    }

    /** Read the contents of the given file. */
    public static String read(File fFileName) throws IOException {
        return read(fFileName, "UTF-8");
    }

    /** Read the contents of the given file. */
    public static String read(File fFileName, String fEncoding) throws
            IOException {
        if (fFileName == null) {
            return null;
        }
        StringBuilder text = new StringBuilder();
        String NL = System.getProperty("line.separator");
        Scanner scanner = new Scanner(new FileInputStream(fFileName), fEncoding);
        try {
            while (scanner.hasNextLine()) {
                text.append(scanner.nextLine()).append(NL);
            }
        } finally {
            scanner.close();
        }
        return text.toString();
    }

    public static File getTempFile(String prefix, String suffix) {
        if (prefix == null) {
            prefix = "";
        }
        if (suffix == null) {
            suffix = "";
        }
        String tmpFile = pu.getProperty("temporary-directory", null);
        String delOnExit = pu.getProperty("delete-on-exit", null);
        File result = null;
        try {
            if (tmpFile != null) {
                result = File.createTempFile(prefix, suffix, new File(tmpFile));
            } else {
                result = File.createTempFile(prefix, suffix);
            }
        } catch (IOException ex) {
            log.error("Cannot create temporary file!", ex);
        }
        if (Boolean.parseBoolean(delOnExit)) {
            result.deleteOnExit();
        }
        return result;
    }
}
