/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.lieskove.jianghongtiao.common.utils.text;

import org.apache.log4j.Logger;
import sk.lieskove.jianghongtiao.common.utils.PropertiesUtils;

import java.io.Serializable;

/**
 * 
 * @author xjuraj e-mail: jjurco.sk_gmail.com
 */
public class StringUtils implements Serializable {
    
    private transient Logger log = Logger.getLogger(StringUtils.class);
    private transient PropertiesUtils pu = new PropertiesUtils(StringUtils.class);
    
        /* remove leading whitespace */
    public static String ltrim(String source) {
        return source.replaceAll("^\\s+", "");
    }

    /* remove trailing whitespace */
    public static String rtrim(String source) {
        return source.replaceAll("\\s+$", "");
    }

    /* replace multiple whitespaces between words with single blank */
    public static String itrim(String source) {
        return source.replaceAll("\\b*\\s{2,}\\b*", " ");
    }

    /**
     * remove all superfluous whitespaces in source string
     * @param source string in which trailing spaces is removed
     * @return string without trailing spaces
     */
    public static String trailingSpaces(String source) {
        return itrim(source).trim();
    }

}
