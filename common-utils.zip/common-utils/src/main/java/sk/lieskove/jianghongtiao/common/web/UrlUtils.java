/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.lieskove.jianghongtiao.common.web;

import org.apache.log4j.Logger;
import sk.lieskove.jianghongtiao.common.utils.PropertiesUtils;

import java.io.Serializable;
import java.net.URL;

/**
 * 
 * @author xjuraj e-mail: jjurco.sk_gmail.com
 */
public class UrlUtils implements Serializable {
    
    private transient Logger log = Logger.getLogger(UrlUtils.class);
    private transient PropertiesUtils pu = new PropertiesUtils(UrlUtils.class);
    
    
    public static String trimUrl8(URL url){
        return trimUrl(url, 8);
    }
    
    public static String trimUrl(URL url, int length){
        return url.getHost()+"/..."+url.toString().substring(url.toString().length()-(length-4));
    }
    
    
}
