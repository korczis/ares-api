/*
 * Copyright (C) 2011 JiangHongTiao <jjurco.sk_gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sk.lieskove.jianghongtiao.common.struct;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Date of create: Oct 9, 2011
 *
 * @author JiangHongTiao <jjurco.sk_gmail.com>
 * @version 2011.1009
 */
public class MapTriple<T, S, R>{
    
    private Map<T, Map<S, R>> values = new HashMap<T, Map<S, R>>();

    public MapTriple(T key, S subKey, R value) {
        Map<S, R> item = new HashMap<S, R>();
        item.put(subKey, value);
        values.put(key, item);
    }

    public MapTriple() {
    }
    
    public Set<T> getKeySet(){
        return values.keySet();
    }
    
    public Map<S, R> getSubMap(T key){
        return values.get(key);
    }
    
    public void put(T key, S subKey, R value){
        Map<S, R> subMap = getSubMap(key);
        if(subMap == null){
            subMap = new HashMap<S, R>();
        }
        subMap.put(subKey, value);
        values.put(key, subMap);
    }

}
