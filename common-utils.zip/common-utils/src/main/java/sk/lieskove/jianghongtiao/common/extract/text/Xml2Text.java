/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.lieskove.jianghongtiao.common.extract.text;

import org.apache.log4j.Logger;
import org.htmlcleaner.HtmlCleaner;
import org.htmlcleaner.TagNode;
import sk.lieskove.jianghongtiao.common.utils.PropertiesUtils;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;

/**
 * Extract textual content of the Xml File
 * @author xjuraj e-mail: jjurco.sk_gmail.com
 */
public class Xml2Text implements Serializable, TextExtractor {

    private transient Logger log = Logger.getLogger(Xml2Text.class);
    private transient PropertiesUtils pu = new PropertiesUtils(Xml2Text.class);

    @Override
    public String extractText(File inputFile) {
        log.debug("Enter Xml2Text with file: "+inputFile.getAbsolutePath());
        try {
            HtmlCleaner cleaner = new HtmlCleaner();
            TagNode clean = cleaner.clean(inputFile);
            String extractedText = clean.getText().toString().trim();
            log.debug("Xml2Text extracted: "+extractedText.length()+" characters.");
            return extractedText;
        } catch (IOException ex) {
            log.error("IO Exception with file: " + inputFile.getAbsolutePath(), ex);
        }
        return null;
    }

    public String extractText(String inputString) {
        log.debug("Enter Xml2Text with string (first 50): "+inputString.substring(0,50));
        HtmlCleaner cleaner = new HtmlCleaner();
        TagNode clean = cleaner.clean(inputString);
        String extractedText = clean.getText().toString().trim();
        log.debug("Xml2Text extracted: "+extractedText.length()+" characters.");
        return extractedText;
    }
}
