/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.lieskove.jianghongtiao.common.extract.text;

import java.io.File;

/**
 * Extract text from various formats
 * @author xjuraj
 */
public interface TextExtractor {
    
    /**
     * Extract text from the input file and return it as string
     * @param inputFile input file 
     * @return extracted file
     */
    public String extractText(File inputFile);
    
}
