/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.lieskove.jianghongtiao.common.utils.text;

import org.apache.log4j.Logger;
import sk.lieskove.jianghongtiao.common.utils.PropertiesUtils;
import weka.core.Stopwords;

import java.io.File;
import java.io.Serializable;
import java.util.Map;
import java.util.TreeMap;

/**
 * 
 * @author xjuraj e-mail: jjurco.sk_gmail.com
 */
public class StopWordsForLang implements Serializable {

    private static transient Logger log = Logger.getLogger(StopWordsForLang.class);
    private transient PropertiesUtils pu = new PropertiesUtils(StopWordsForLang.class);
    private static final Map<String, Stopwords> stopWordsLanguages = new TreeMap<String, Stopwords>();

    private StopWordsForLang() {
    }

    /**
     * load Stop words for language code. Language code specifies extension of the
     * file in the directory: &lt;Working dir&gt;/resources/stopwords/stopwords.&lt;ext&gt;
     * and in the same time it is the code of the language
     * 
     * @param code language code for the stop words
     * @return set of stop words
     */
    public static Stopwords getStopWordsForLang(String code) {
        if (code == null) {
            throw new NullPointerException("Code was null!");
        }
        if (code.equals("")) {
            throw new IllegalArgumentException("Language code was empty!");
        }
        if (!stopWordsLanguages.containsKey(code)) {
            File f = new File("resources/stopwords/stopwords." + code);
            if (f.exists()) {
                Stopwords s = new Stopwords();
                try {
                    s.read(f);
                    stopWordsLanguages.put(code, s);
                } catch (Exception ex) {
                    log.error("cannot read stop-words file for language: " + code
                            + " Program searches for file: " + f.getAbsolutePath());
                }
            } else {
                log.error("Cannot read stop words for language code: "+code+
                        " from file: "+f.getAbsolutePath());
            }

        }
        return stopWordsLanguages.get(code);
    }
}
