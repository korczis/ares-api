/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.lieskove.jianghongtiao.common.utils;

import java.io.Serializable;
import org.apache.log4j.Logger;

/**
 * 
 * @author xjuraj e-mail: jjurco.sk_gmail.com
 */
public class DesktopUtils implements Serializable {

    private transient Logger log = Logger.getLogger(DesktopUtils.class);
    private transient PropertiesUtils pu = new PropertiesUtils(DesktopUtils.class);

    public static void openUrlInDefaultBrowser(String url) {
        if (!java.awt.Desktop.isDesktopSupported()) {
            System.err.println("Desktop is not supported (fatal)");
            System.exit(1);
        }
        java.awt.Desktop desktop = java.awt.Desktop.getDesktop();

        if (!desktop.isSupported(java.awt.Desktop.Action.BROWSE)) {
            System.err.println("Desktop doesn't support the browse action (fatal)");
            System.exit(1);
        }

        try {
            java.net.URI uri = new java.net.URI(url);
            desktop.browse(uri);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
