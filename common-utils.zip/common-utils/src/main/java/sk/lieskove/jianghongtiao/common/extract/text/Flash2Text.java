/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.lieskove.jianghongtiao.common.extract.text;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.log4j.Logger;
import sk.lieskove.jianghongtiao.common.system.RunCommand;
import sk.lieskove.jianghongtiao.common.utils.PropertiesUtils;
import sk.lieskove.jianghongtiao.common.utils.text.StringUtils;
import sk.lieskove.jianghongtiao.common.utils.xml.Transformation;

import java.io.File;
import java.io.Serializable;

/**
 * 
 * @author xjuraj e-mail: jjurco.sk_gmail.com
 */
public class Flash2Text implements Serializable, TextExtractor{
    
    private transient Logger log = Logger.getLogger(Flash2Text.class);
    private transient PropertiesUtils pu = new PropertiesUtils(Flash2Text.class);
    
    private final File SWF_MILL_PATH = new File(pu.getProperty("swfmill-path"));
    private final String SWF_MILL = pu.getProperty("swfmill-path");

    @Override
    public String extractText(File inputFile) { //_PATH.getAbsolutePath()
        String runCommand = RunCommand.runCommand(SWF_MILL + " swf2xml "+inputFile.getAbsolutePath());
        String applyTemplate = Transformation.applyTemplate(runCommand, new File("resources/transform/swf/swfmill.xsl"));
        String unescaped = StringEscapeUtils.unescapeHtml(StringUtils.trailingSpaces(applyTemplate));
        Html2Text html2Text = new Html2Text();
        return html2Text.extractText(StringEscapeUtils.unescapeHtml(unescaped));
    }
}
