/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.lieskove.jianghongtiao.common.extract.text;

import org.junit.*;

import java.io.File;

/**
 *
 * @author xjuraj
 */
public class Flash2TextTest {
    
    public Flash2TextTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of extractText method, of class Flash2Text.
     */
    @Test
    public void testExtractText() {
        System.out.println("extractText");
        File inputFile = new File("test-files/perfumes.swf");
        Flash2Text instance = new Flash2Text();
        String expResult = "";
        String result = instance.extractText(inputFile);
        System.out.println(result);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }
}
