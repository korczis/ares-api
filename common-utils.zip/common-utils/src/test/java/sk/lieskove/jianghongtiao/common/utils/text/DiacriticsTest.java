/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.lieskove.jianghongtiao.common.utils.text;

import junit.framework.TestCase;
import org.junit.*;

import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @author xjuraj
 */
public class DiacriticsTest extends TestCase {
    private String DIACRITICS_a = "áàăắằẵẳâấầẫẩǎåǻäǟãȧǡąāảȁȃạặậḁⱥᶏɐɑ";
    private String DIACRITICS_A = "ÁÀĂẮẰẴẲÂẤẦẪẨǍÅǺÄǞÃȦǠĄĀẢȀȂẠẶẬḀȺⱯⱭ";
    private String DIACRITICS_b = "ḃḅḇƀɓƃᵬᶀ";
    private String DIACRITICS_B = "ḂḄḆɃƁƂ";
    private String DIACRITICS_c = "ćĉčċçḉȼƈɕ";
    private String DIACRITICS_C = "ĆĈČĊÇḈȻƇ";
    private String DIACRITICS_d = "ďḋḑḍḓḏđɖɗƌᵭᶁᶑȡ∂";
    private String DIACRITICS_D = "ĎḊḐḌḒḎĐƉƊƋ";
    private String DIACRITICS_e = "éèĕêếềễểěëẽėȩḝęēḗḕẻȅȇẹệḙḛɇᶒⱸ";
    private String DIACRITICS_E = "ÉÈĔÊẾỀỄỂĚËẼĖȨḜĘĒḖḔẺȄȆẸỆḘḚɆ";
    private String DIACRITICS_f = "ḟƒᵮᶂ";
    private String DIACRITICS_F = "ḞƑ";
    private String DIACRITICS_g = "ǵğĝǧġģḡǥɠᶃ";
    private String DIACRITICS_G = "ǴĞĜǦĠĢḠǤƓ";
    private String DIACRITICS_h = "ĥȟḧḣḩḥḫẖħⱨ";
    private String DIACRITICS_H = "ĤȞḦḢḨḤḪĦⱧ";
    private String DIACRITICS_i = "íìĭîǐïḯĩįīỉȉȋịḭɨᵻᶖı";
    private String DIACRITICS_I = "ÍÌĬÎǏÏḮĨĮĪỈȈȊỊḬƗİ";
    private String DIACRITICS_j = "ĵɉǰȷʝɟʄ";
    private String DIACRITICS_J = "ĴɈ";
    private String DIACRITICS_k = "ḱǩķḳḵƙⱪᶄꝁ";
    private String DIACRITICS_K = "ḰǨĶḲḴƘⱩꝀ";
    private String DIACRITICS_l = "ĺľļḷḹḽḻłŀƚⱡɫɬᶅɭȴ";
    private String DIACRITICS_L = "ĹĽĻḶḸḼḺŁĿȽⱠⱢ";
    private String DIACRITICS_m = "ḿṁṃᵯᶆɱ";
    private String DIACRITICS_M = "ḾṀṂⱮ";
    private String DIACRITICS_n = "ńǹňñṅņṇṋṉɲƞŋꞑᵰᶇɳȵ";
    private String DIACRITICS_N = "ŃǸŇÑṄŅṆṊṈƝȠŊꞐ";
    private String DIACRITICS_o = "óòŏôốồỗổǒöȫőõṍṏȭȯȱøǿǫǭōṓṑỏȍȏơớờỡởợọộɵɔⱺ";
    private String DIACRITICS_O = "ÓÒŎÔỐỒỖỔǑÖȪŐÕṌṎȬȮȰØǾǪǬŌṒṐỎȌȎƠỚỜỠỞỢỌỘƟƆ";
    private String DIACRITICS_p = "ṕṗᵽƥᵱᶈ";
    private String DIACRITICS_P = "ṔṖⱣƤ";
    private String DIACRITICS_q = "ɋƣʠ";
    private String DIACRITICS_Q = "ɊƢ";
    private String DIACRITICS_r = "ŕřṙŗȑȓṛṝṟɍɽᵲᶉɼɾᵳ";
    private String DIACRITICS_R = "ŔŘṘŖȐȒṚṜṞɌⱤ";
    private String DIACRITICS_s = "śṥŝšṧṡẛşṣṩșᵴᶊʂȿ";
    private String DIACRITICS_S = "ŚṤŜŠṦṠŞṢṨȘ";
    private String DIACRITICS_t = "ťṫţṭțṱṯŧⱦƭʈẗᵵƫȶ";
    private String DIACRITICS_T = "ŤṪŢṬȚṰṮŦȾƬƮ";
    private String DIACRITICS_u = "úùŭûǔůüǘǜǚǖűũṹųūṻủȕȗưứừữửựụṳṷṵʉᵾᶙ";
    private String DIACRITICS_U = "ÚÙŬÛǓŮÜǗǛǙǕŰŨṸŲŪṺỦȔȖƯỨỪỮỬỰỤṲṶṴɄ";
    private String DIACRITICS_v = "ṽṿʋᶌⱱⱴ";
    private String DIACRITICS_V = "ṼṾƲ";
    private String DIACRITICS_w = "ⱳẘẃẁŵẅẇẉ";
    private String DIACRITICS_W = "ẂẀŴẄẆẈⱲ";
    private String DIACRITICS_x = "ẍẋᶍ";
    private String DIACRITICS_X = "ẌẊ";
    private String DIACRITICS_y = "ýỳŷẙÿỹẏȳỷỵɏƴʏ";
    private String DIACRITICS_Y = "ÝỲŶŸỸẎȲỶỴɎƳ";
    private String DIACRITICS_z = "źẑžżẓẕƶȥⱬᵶᶎʐʑɀ";
    private String DIACRITICS_Z = "ŹẐŽŻẒẔƵȤⱫ";
    private String DIACRITICS_OTHER = "̈͘";
    
    private String EXP_a = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    private String EXP_A = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
    private String EXP_b = "bbbbbbbb";
    private String EXP_B = "BBBBBB";
    private String EXP_c = "ccccccccc";
    private String EXP_C = "CCCCCCCC";
    private String EXP_d = "ddddddddddddddd";
    private String EXP_D = "DDDDDDDDDD";
    private String EXP_e = "eeeeeeeeeeeeeeeeeeeeeeeeeeee";
    private String EXP_E = "EEEEEEEEEEEEEEEEEEEEEEEEEE";
    private String EXP_f = "ffff";
    private String EXP_F = "FF";
    private String EXP_g = "gggggggggg";
    private String EXP_G = "GGGGGGGGG";
    private String EXP_h = "hhhhhhhhhh";
    private String EXP_H = "HHHHHHHHH";
    private String EXP_i = "iiiiiiiiiiiiiiiiiii";
    private String EXP_I = "IIIIIIIIIIIIIIIII";
    private String EXP_j = "jjjjjjj";
    private String EXP_J = "JJ";
    private String EXP_k = "kkkkkkkkk";
    private String EXP_K = "KKKKKKKK";
    private String EXP_l = "llllllllllllllll";
    private String EXP_L = "LLLLLLLLLLLL";
    private String EXP_m = "mmmmmm";
    private String EXP_M = "MMMM";
    private String EXP_n = "nnnnnnnnnnnnnnnnn";
    private String EXP_N = "NNNNNNNNNNNNN";
    private String EXP_o = "ooooooooooooooooooooooooooooooooooooooo";
    private String EXP_O = "OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO";
    private String EXP_p = "pppppp";
    private String EXP_P = "PPPP";
    private String EXP_q = "qqq";
    private String EXP_Q = "QQ";
    private String EXP_r = "rrrrrrrrrrrrrrrr";
    private String EXP_R = "RRRRRRRRRRR";
    private String EXP_s = "sssssssssssssss";
    private String EXP_S = "SSSSSSSSSS";
    private String EXP_t = "ttttttttttttttt";
    private String EXP_T = "TTTTTTTTTTT";
    private String EXP_u = "uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu";
    private String EXP_U = "UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU";
    private String EXP_v = "vvvvvv";
    private String EXP_V = "VVV";
    private String EXP_w = "wwwwwwww";
    private String EXP_W = "WWWWWWW";
    private String EXP_x = "xxx";
    private String EXP_X = "XX";
    private String EXP_y = "yyyyyyyyyyyyy";
    private String EXP_Y = "YYYYYYYYYYY";
    private String EXP_z = "zzzzzzzzzzzzzz";
    private String EXP_Z = "ZZZZZZZZZ";
    private String EXP_OTHER = "̱͘";
    private Map<String, String> diaExp = new TreeMap<String, String>();

    {
        diaExp.put(DIACRITICS_A, EXP_A);
        diaExp.put(DIACRITICS_B, EXP_B);
        diaExp.put(DIACRITICS_C, EXP_C);
        diaExp.put(DIACRITICS_D, EXP_D);
        diaExp.put(DIACRITICS_E, EXP_E);
        diaExp.put(DIACRITICS_F, EXP_F);
        diaExp.put(DIACRITICS_G, EXP_G);
        diaExp.put(DIACRITICS_H, EXP_H);
        diaExp.put(DIACRITICS_I, EXP_I);
        diaExp.put(DIACRITICS_J, EXP_J);
        diaExp.put(DIACRITICS_K, EXP_K);
        diaExp.put(DIACRITICS_L, EXP_L);
        diaExp.put(DIACRITICS_M, EXP_M);
        diaExp.put(DIACRITICS_N, EXP_N);
        diaExp.put(DIACRITICS_O, EXP_O);
        diaExp.put(DIACRITICS_P, EXP_P);
        diaExp.put(DIACRITICS_Q, EXP_Q);
        diaExp.put(DIACRITICS_R, EXP_R);
        diaExp.put(DIACRITICS_S, EXP_S);
        diaExp.put(DIACRITICS_T, EXP_T);
        diaExp.put(DIACRITICS_U, EXP_U);
        diaExp.put(DIACRITICS_V, EXP_V);
        diaExp.put(DIACRITICS_W, EXP_W);
        diaExp.put(DIACRITICS_X, EXP_X);
        diaExp.put(DIACRITICS_Y, EXP_Y);
        diaExp.put(DIACRITICS_Z, EXP_Z);
        diaExp.put(DIACRITICS_a, EXP_a);
        diaExp.put(DIACRITICS_b, EXP_b);
        diaExp.put(DIACRITICS_c, EXP_c);
        diaExp.put(DIACRITICS_d, EXP_d);
        diaExp.put(DIACRITICS_e, EXP_e);
        diaExp.put(DIACRITICS_f, EXP_f);
        diaExp.put(DIACRITICS_g, EXP_g);
        diaExp.put(DIACRITICS_h, EXP_h);
        diaExp.put(DIACRITICS_i, EXP_i);
        diaExp.put(DIACRITICS_j, EXP_j);
        diaExp.put(DIACRITICS_k, EXP_k);
        diaExp.put(DIACRITICS_l, EXP_l);
        diaExp.put(DIACRITICS_m, EXP_m);
        diaExp.put(DIACRITICS_n, EXP_n);
        diaExp.put(DIACRITICS_o, EXP_o);
        diaExp.put(DIACRITICS_p, EXP_p);
        diaExp.put(DIACRITICS_q, EXP_q);
        diaExp.put(DIACRITICS_r, EXP_r);
        diaExp.put(DIACRITICS_s, EXP_s);
        diaExp.put(DIACRITICS_t, EXP_t);
        diaExp.put(DIACRITICS_u, EXP_u);
        diaExp.put(DIACRITICS_v, EXP_v);
        diaExp.put(DIACRITICS_w, EXP_w);
        diaExp.put(DIACRITICS_x, EXP_x);
        diaExp.put(DIACRITICS_y, EXP_y);
        diaExp.put(DIACRITICS_z, EXP_z);
    }

    public DiacriticsTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    @Override
    public void setUp() {
    }

    @After
    @Override
    public void tearDown() {
    }

    /**
     * Test of removeDiacritics method, of class Diacritics.
     */
    @Test
    public void testRemoveDiacritics() throws Exception {
        System.out.println("removeDiacritics");
        assertEquals("ooo", Diacritics.removeDiacritics("óòŏ"));
        for (Iterator it = diaExp.keySet().iterator(); it.hasNext();) {
            String dia = (String) it.next();
            String exp = diaExp.get(dia);
            assertEquals(exp, Diacritics.removeDiacritics(dia));
        }
    }

    /**
     * Test of removeDiacritics method, of class Diacritics.
     */
    @Test
    public void testRemoveSpecialDiacriticSigns() throws Exception {
        System.out.println("removeDiacritics");
        assertEquals("", Diacritics.removeSpecialDiacriticSigns("̩̩̱̱̃̌̊̈̈̈͘"));
        assertEquals("ss", Diacritics.removeSpecialDiacriticSigns("ss̩̩̱̱̃̌̊̈̈̈͘"));
        assertEquals("sd", Diacritics.removeSpecialDiacriticSigns("̩̩̃̌̊̈s̈̈ḏ̱͘"));
    }
    
    /**
     * Test of containsDiacritics method, of class Diacritics.
     */
    @Test
    public void testContainsDiacritics() {
        System.out.println("containsDiacritics");

        for (Iterator it = diaExp.keySet().iterator(); it.hasNext();) {
            String dia = (String) it.next();
            String exp = diaExp.get(dia);
            for (int i = 0; i < dia.length(); i++) {
                char ch = dia.charAt(i);
                assertTrue("Character: " + ch + "["+i+"] does not contain diacritics?", Diacritics.containsDiacritics(Character.toString(ch)));
            }
            for (int i = 0; i < exp.length(); i++) {
                char ch = exp.charAt(i);
                assertFalse("Character: " + ch + "["+i+"] contains diacritics?", Diacritics.containsDiacritics(Character.toString(ch)));
            }
        }
    }
}
