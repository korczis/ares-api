/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.lieskove.jianghongtiao.common.extract.text;

import org.junit.*;

import java.io.File;

import static org.junit.Assert.assertEquals;

/**
 *
 * @author xjuraj
 */
public class OpenOffice2TextTest {
    
    public OpenOffice2TextTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of extractText method, of class OpenOffice2Text.
     */
    @Test
    public void testExtractText() {
        System.out.println("extractText");
        File inputFile = new File("test-files/writer.odt");
        OpenDocument2Text instance = new OpenDocument2Text();
        String expResult = "Postup prace\n\nNa porozumenie postupu vyhladavania "
                + "ludi budem vyhladat pomocou googlu mena ludi a zosumarizovanie "
                + "postupu na zaklade\t\t\t ktoreho som sa rozhodoval, ci dany "
                + "dokument je dolezity a ktory som vylucil a  preco. Tieto "
                + "dokumenty budu dalej sluzit na naucenie sa s ucitelom. "
                + "Algoritmus bude vracat nejaku pravdepodobnost s ktorou je "
                + "dany dokument pre mna zaujimavy, alebo nie. \nV texte "
                + "identifikujem niektore dolezite klucove slova ktore by mohli "
                + "byt dolezite pre identifikaciu danej osoby.";
        String result = instance.extractText(inputFile);
        assertEquals(expResult, result);
        
        
        inputFile = new File("test-files/spreadsheet.ods");
        instance = new OpenDocument2Text();
        expResult = "66.7%\tUTF-8\n18.0%\tISO-8859-1\n3.6%\tGB2312\n3.4%\t"
                + "Windows-1251\n1.8%\tWindows-1252\n1.8%\tShift JIS\n0.9%\tGBK\n"
                + "0.9%\tWindows-1256\n0.6%\tISO-8859-2\n\n\nSource: "
                + "http://w3techs.com/technologies/overview/character_encoding"
                + "/all\n\n\nMichal\tCerveny\nMatej\tZeleny\nJakub\tSedy";
        result = instance.extractText(inputFile);
        assertEquals(expResult, result);
        
        
        inputFile = new File("test-files/presentation.odp");
        instance = new OpenDocument2Text();
        expResult = "Fakulta informatiky, Masarykova univerzita\nProgram pre "
                + "analýzu DNA sekvencií z hľadiska výskytu triplexov\n\nJuraj "
                + "Jurčo\n1. Motivácia\nCelý život je súborom informácií\nDĺžka"
                + " ľudskej DNA je približne 3 miliardy bázových párov\n(Ne)kan"
                + "onická štruktúra DNA\nNiektoré biologické deje môžu byť ovpl"
                + "yvnené týmito štruktúrami\nTriplexy\n\nJuraj Jurčo\nProgram "
                + "pre analýzu DNA sekvencií z hľadiska výskytu triplexov\n\nPo"
                + "čítačové spracovanie\nRučná / počítačová kontrola\nNávrh a i"
                + "mplementácia algoritmu na vyhľadávanie triplexových štruktúr"
                + "\nJuraj Jurčo\nProgram pre analýzu DNA sekvencií z hľadiska "
                + "výskytu triplexov\nNávrh\nReprezentácia prehľadávanej sekven"
                + "cie\n\n\nPredpočítané polia\nNekomplementárnych prvkov\nZmen"
                + "a orientácie vlákna\nPolia s počtom chýb vo vlákne\n\nJuraj "
                + "Jurčo\nProgram pre analýzu DNA sekvencií z hľadiska výskytu "
                + "triplexov\nAlgoritmus vyhľadávania\nRýchla kontrola\nPomocou"
                + " predpočítaných polí\nNeodhalené všetky chyby – počet nájden"
                + "ých chýb je menší ako v skutočnosti\nDôkladná kontrola\nKont"
                + "rola po jednom komplementárnom páre\nPočítajú sa niektoré vla"
                + "stnosti\n(celkový počet chýb, počet nekomplementárnych nukleo"
                + "tidov, zmien orientácie vlákna, ich najdlhšie oblasti a ďalši"
                + "e)\nJuraj Jurčo\nProgram pre analýzu DNA sekvencií z hľadisk"
                + "a výskytu triplexov\nImplementácia\nImplementovaný v jazyku "
                + "Java\nTriedy majú vlastné rozhranie\nNáhrada modulov\nNačíta"
                + "nie / výpis dát\nRozšírenie programu\ncmd verzia, GUI, Webové"
                + " rozhranie\n\nJuraj Jurčo\nProgram pre analýzu DNA sekvencií "
                + "z hľadiska výskytu triplexov\nTestovanie\nTesty modulov\nVýk"
                + "onnostné testy\nJuraj Jurčo\nProgram pre analýzu DNA sekvenci"
                + "í z hľadiska výskytu triplexov\nVyjadrenie k posudkom\nJuraj "
                + "Jurčo\nProgram pre analýzu DNA sekvencií z hľadiska výskytu t"
                + "riplexov\nĎakujem za pozornosť :-)\nJuraj Jurčo\nProgram pre "
                + "analýzu DNA sekvencií z hľadiska výskytu triplexov";
        result = instance.extractText(inputFile);
        assertEquals(expResult, result);
        
        
    }
}
