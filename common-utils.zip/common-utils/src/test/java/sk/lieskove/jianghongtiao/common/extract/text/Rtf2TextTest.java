/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.lieskove.jianghongtiao.common.extract.text;

import org.junit.*;

import java.io.File;

import static org.junit.Assert.assertEquals;

/**
 *
 * @author xjuraj
 */
public class Rtf2TextTest {
    
    public Rtf2TextTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of extractText method, of class Rtf2Text.
     */
    @Test
    public void testExtractText() {
        System.out.println("extractText");
        File inputFile = new File("test-files/rtfDiacritics.rtf");
        Rtf2Text instance = new Rtf2Text();
        String result = instance.extractText(inputFile);
        String expString = "+ľščťžýáíé=äúň§ô.,+ěščřžýáíé=)úů.,";
        assertEquals(expString, result);
    }
}
