/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.lieskove.jianghongtiao.common.utils.text;

import org.junit.*;

import static org.junit.Assert.assertEquals;

/**
 *
 * @author xjuraj
 */
public class StringUtilsTest {
    
    public StringUtilsTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of ltrim method, of class StringUtils.
     */
    @Test
    public void testLtrim() {
        System.out.println("ltrim");
        String source = "       asd  ";
        String expResult = "asd  ";
        String result = StringUtils.ltrim(source);
        assertEquals(expResult, result);
    }

    /**
     * Test of rtrim method, of class StringUtils.
     */
    @Test
    public void testRtrim() {
        System.out.println("rtrim");
        String source = "  asd    ";
        String expResult = "  asd";
        String result = StringUtils.rtrim(source);
        assertEquals(expResult, result);
    }

    /**
     * Test of itrim method, of class StringUtils.
     */
    @Test
    public void testItrim() {
        System.out.println("itrim");
        String source = "   asd      asd   ";
        String expResult = " asd asd ";
        String result = StringUtils.itrim(source);
        assertEquals(expResult, result);
    }

    /**
     * Test of trailingSpaces method, of class StringUtils.
     */
    @Test
    public void testTrailingSpaces() {
        System.out.println("trailingSpaces");
        String source = "   asd \n\n\n\n\n\n\n\n\n  asd   ";
        String expResult = "asd asd";
        String result = StringUtils.trailingSpaces(source);
        assertEquals(expResult, result);
    }
}
